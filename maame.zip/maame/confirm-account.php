<?php 
    
    require_once ('connection/conn.php');

    include ("head.php");

    $message = '';
    if (isset($_GET['code_activation'])) {
        
        $query = "SELECT * FROM admissions WHERE vericode = :vericode LIMIT 1";
        $statement = $conn->prepare($query);
        $statement->execute(
            array(
                ':vericode' => $_GET['code_activation']
            )
        );
        $no_of_row = $statement->rowCount();

        if ($no_of_row > 0) {
            $result = $statement->fetchAll();
            foreach ($result as $row) {
                if ($row['verified'] == '0') {
                    $update_query = "
                        UPDATE admissions
                        SET verified = '1'
                        WHERE id = '".$row['id']."'
                    ";
                    $statement = $conn->prepare($update_query);
                    $sub_result = $statement->execute();
                    if (isset($sub_result)) {
                        $message = '
                            <h1 class="display-5 fw-bold">Email verified.</h1>
                            <p class="lead text-secondary my-4">Please your email account has been successfully verified. Do not worry much, you can go ahead and complete your admission registration. And please make sure you give us the exact correct details while filling the forms to make it easier for us both. Thank you.</p>
                            <a href="index.php/sign-in.php" class="btn btn-outline-white btn-lg btn-with-icon rounded-pill">Login here. <i
                          class="bi bi-arrow-right"></i></a>
                        ';
                    }
                } else {
                    $message = '
                        <h1 class="display-5 fw-bold">Already verified.</h1>
                        <p class="lead text-secondary my-4">Please you have already verified your email account. Continue your admission forms by logging into your portal. Thank you.</p>
                        <a href="index.php" class="btn btn-outline-white btn-lg btn-with-icon rounded-pill">Visit site. <i
                          class="bi bi-arrow-right"></i></a>
                    ';
                }
            }
        } else {
            $message = '
                <h1 class="display-5 fw-bold">Invalid link</h1>
                <p class="lead text-secondary my-4">The link provided or opened is invalid, check your email to get the correct link. Thank you.</p>
                        <a href="index.php" class="btn btn-outline-white btn-lg btn-with-icon rounded-pill">Visit site. <i
                          class="bi bi-arrow-right"></i></a>
            ';
        }


    }

?>


        <section class="bg-green py-15 py-xl-20 mx-xl-3 overflow-hidden">
            <div class="container level-3">
                <div class="row">
                    <div class="col-lg-8 col-xl-6 inverted text-center text-lg-start">
                        <h2 class="h1 mb-0">Hey ...</h2>
                        <?= $message; ?>
                    </div>
                </div>
            </div>
            <figure class="background background-gradient-horizontal background-parallax"
              style="background-image: url('media/pic3.jpg')" data-bottom-top="transform: translateY(0%);"
              data-top-bottom="transform: translateY(20%);"></figure>
        </section>


<?php 
    include ("footer.php");
?>