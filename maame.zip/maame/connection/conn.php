<?php

	// Connection To Database
	$conn = new PDO("mysql:host=localhost;dbname=maame", "root", "");
	session_start();

	require_once $_SERVER['DOCUMENT_ROOT'].'/maame/config.php';
 	require_once BASEURL.'helpers/helpers.php';

 	if (isset($_SESSION['adminId'])) {
 		$data = array(
 			':admin_id' => (int)$_SESSION['adminId']
 		);
 		$sql = "SELECT * FROM admin WHERE admin_id = :admin_id LIMIT 1";
 		$statement = $conn->prepare($sql);
 		$statement->execute($data);

 		foreach ($statement->fetchAll() as $row) {
 			$fullName = ucwords($row['fname'] . ' ' . $row['lname']);
 			$lName = ucwords($row['fname']);
 			$fname = ucwords($row['lname']);
 		}
 	}

 	// GET STUDENT ADMISSION DETAILS
 	if (isset($_SESSION['id'])) {
 		$select_query = "
 			SELECT * FROM admissions
 			INNER JOIN admission_details
 			ON admission_details.admission_id = admissions.id
 			WHERE id = :id
 			LIMIT 1";
 		$statement = $conn->prepare($select_query);
 		$statement->execute([':id' => (int)$_SESSION['id']]);
 		$select_result = $statement->fetchAll();

 		foreach ($select_result as $select_row) {
 			// code...
 		}




 	}


 	// Display on Messages on Errors And Success
 	if (isset($_SESSION['flash_success'])) {
 	 	echo '<div class="bg-success" id="temporary" style="margin-top: 60px; color: #fff;"><p class="text-center">'.$_SESSION['flash_success'].'</p></div>';
 	 	unset($_SESSION['flash_success']);
 	 }

 	 if (isset($_SESSION['flash_error'])) {
 	 	echo '<div class="bg-danger" id="temporary" style="margin-top: 60px; color: #fff;"><p class="text-center">'.$_SESSION['flash_error'].'</p></div>';
 	 	unset($_SESSION['flash_error']);
 	 }




?>
