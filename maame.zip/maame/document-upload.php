<?php   

    require_once ("connection/conn.php");

    if (!isset($_SESSION['id'])) {
        header('Location: sign-in.php');
    }

    if ($select_row['done'] == 1) {
        header('Location: dashboard.php');
    }
    
    include ("head.php");

    if (isset($_POST['submit'])) {
        $exams_type = sanitize($_POST['exams_type']);
        $school = sanitize($_POST['name_of_sch']);
        $doc_type = sanitize($_POST['doc_type']);

        if ($_FILES["doc_file"]["name"] != '') {
            // FILE
            $doc_test = explode(".", $_FILES["doc_file"]["name"]);
            $doc_extension = end($doc_test);
            $doc_name = uniqid('', true).".".$doc_extension;
            $location = BASEURL.'media/students_docs/'.$doc_name;
            move_uploaded_file($_FILES["doc_file"]["tmp_name"], $location);
        } else {
            $doc_name = $select_row['upload_cert'];
        }
       
        $update_query = "
            UPDATE admission_details
            SET exams_type = :exams_type, school = :school, cert_info = :cert_info, upload_cert = :upload_cert
            WHERE admission_id = :admission_id
        ";
        $statement = $conn->prepare($update_query);
        $result = $statement->execute([
            ':exams_type'       => $exams_type,
            ':school'           => $school,
            ':cert_info'        => $doc_type,
            ':upload_cert'      => $doc_name,
            ':admission_id'     => (int)$_SESSION['id']
        ]);

        if (isset($result)) {
            header('Location: done.php');
        }
    }
?>

<body class="bg-light">

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-light bg-light border-bottom">
        <div class="container">
            <a href="account-settings.php" class="navbar-brand"><img src="media/logo-1.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>

                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#userNav"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-hover d-none d-lg-block">
                    <a class="nav-link nav-icon" role="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="account-settings.php">Bio Data</a></li>
                        <li><a class="dropdown-item " href="contact-info.php">Contact Information</a></li>
                        <li><a class="dropdown-item " href="choice-prog.php">Choice of Programmes</a></li>
                        <li><a class="dropdown-item " href="examination-history.php">Examination History</a></li>
                        <li><a class="dropdown-item active" href="document-upload.php">Document Upload</a></li>
                        <li><a class="dropdown-item text-red" href="sign-out.php">Log Out</a></li>
                    </ul>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                    aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="dashboard.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li> -->
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
  </nav>

    <div class="offcanvas-wrap">
        <section class="split">
            <div class="container">
                <div class="row justify-content-between">

                    <aside class="col-lg-3 split-sidebar">
                        <nav class="sticky-top d-none d-lg-block">
                            <ul class="nav nav-minimal flex-column" id="toc-nav">
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="dashboard.php">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="account-settings.php">Bio Data</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="contact-info.php">Contact Information</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="choice-prog.php">Choice of Programmes</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="examination-history.php">Examination History</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg active" href="document-upload.php">Document Upload</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="done.php">Done</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg text-red" href="sign-out.php">Sign Out</a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <div class="col-lg-9 split-content">
                        <div class="row">
                            <div class="col-lg-10">
                                <h1>Document Upload</h1>
                                <div class="alert alert-success mb-0" role="alert">
                                    Please update your document details.
                                </div>
                            </div>
                        </div>

                        <section>
                            <div class="row">
                                <div class="col-lg-10">
                                    <h3 class="fs-4">Documents</h3>
                                    <div class="card bg-opaque-white">
                                        <div class="card-body bg-white">
                                            <form class="row g-2 g-lg-3" method="POST" action="document-upload.php" enctype="multipart/form-data">
                                                <div class="col-md-12">
                                                    <label for="exams_type" class="form-label">Examination Type</label>
                                                    <select id="exams_type" class="form-select" name="exams_type" required>
                                                        <option value="">Select your exam type</option>
                                                        <option value="W A S S C E (School)" <?= ((isset($_POST['exams_type']) == 'W A S S C E (School)' || $select_row['exams_type'] == 'W A S S C E (School)')?'selected':''); ?>>W A S S C E (School)</option>
                                                        <option value="W A S S C E (Private)" <?= ((isset($_POST['doc_type']) == 'W A S S C E (Private)' || $select_row['exams_type'] == 'W A S S C E (Private)')?'selected':''); ?>>W A S S C E (Private)</option>
                                                        <option value="S S S C E" <?= ((isset($_POST['doc_type']) == 'S S S C E' || $select_row['exams_type'] == 'S S S C E')?'selected':''); ?>>S S S C E</option>
                                                    </select>
                                                    <small class="text-danger">NB: Choose the appropriate examination type please.</small>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="name_of_sch" class="form-label">Name of School</label>
                                                    <select id="name_of_sch" class="form-select" name="name_of_sch" required>
                                                        <option value="">Select school's name</option>
                                                        <option value="Navrongo Senior High School" <?= ((isset($_POST['name_of_sch']) == 'Navrongo Senior High School' || $select_row['cert_info'] == 'Navrongo Senior High School')?'selected':''); ?>>Navrongo Senior High School</option>
                                                        <option value="Bolgatanga Senior High School" <?= ((isset($_POST['name_of_sch']) == 'Bolgatanga Senior High School' || $select_row['cert_info'] == 'Bolgatanga Senior High School')?'selected':''); ?>>Bolgatanga Senior High School</option>
                                                        <option value="Tamale Senior High School" <?= ((isset($_POST['name_of_sch']) == 'Tamale Senior High School' || $select_row['cert_info'] == 'Tamale Senior High School')?'selected':''); ?>>Tamale Senior High School</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="doc_type" class="form-label">Document Type</label>
                                                    <select id="doc_type" class="form-select" name="doc_type" required>
                                                        <option value="">Select document type</option>
                                                        <option value="Transcript" <?= ((isset($_POST['doc_type']) == 'Transcript' || $select_row['cert_info'] == 'Transcript')?'selected':''); ?>>Transcript</option>
                                                        <option value="Certificate" <?= ((isset($_POST['doc_type']) == 'Certificate' || $select_row['cert_info'] == 'Certificate')?'selected':''); ?>>Certificate</option>
                                                    </select>
                                                    <small class="text-danger">NB: Choose the appropriate document type for the file you are uploading.</small>
                                                </div>
                                                <div class="col-md-12">
                                                    <?php if ($select_row['upload_cert'] == ''): ?>
                                                        <label for="doc_file" class="form-label">Document File</label>
                                                        <input type="file" name="doc_file" class="form-control" id="doc_file" accept=".pdf, .jpeg, .jpg, .png, .JPG, .PNG" required>
                                                        <small class="text-danger">Accepted format: .pdf, .jpeg, .jpg, .png, .JPG, .PNG files only.</small>
                                                    <?php else: ?>
                                                        <em>File uploaded successfully,</em> <a href="media/students_docs/<?= $select_row['upload_cert']; ?>" target="_blank">preview here...</a><br>
                                                        <a href="" class="text-danger">(x) click here to remove file to re-upload</a>
                                                        <input type="file" name="doc_file" class="form-control" id="doc_file" accept=".pdf, .jpeg, .jpg, .png, .JPG, .PNG" style="display: none;">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-12">
                                                    <button type="submit" name="submit" id="submit" class="btn btn-success">Submit Document Upload</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

    </div>


    <?php 
        include ("footer.php");
    ?>