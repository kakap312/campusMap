<?php   

    require_once ("connection/conn.php");

    if (!isset($_SESSION['id'])) {
        header('Location: sign-in.php');
    }

    include ("head.php");
?>

<body class="bg-light">

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-light bg-light border-bottom">
        <div class="container">
            <a href="account-settings.php" class="navbar-brand"><img src="media/logo-1.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>

                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#userNav"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-hover d-none d-lg-block">
                    <a class="nav-link nav-icon" role="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item active" href="dashboard.php">Dashboard</a></li>
                        <?php if ($select_row['done'] == 0): ?>
                            <li><a class="dropdown-item" href="account-settings.php">Bio Data</a></li>
                            <li><a class="dropdown-item " href="contact-info.php">Contact Information</a></li>
                            <li><a class="dropdown-item " href="choice-prog.php">Choice of Programmes</a></li>
                            <li><a class="dropdown-item " href="examination-history.php">Choice of Programmes</a></li>
                            <li><a class="dropdown-item" href="document-upload.php">Document Upload</a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item text-red" href="sign-out.php">Log Out</a></li>
                    </ul>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                    aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="account-settings.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li> -->
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
  </nav>

    <div class="offcanvas-wrap">
        <section class="split">
            <div class="container">
                <div class="row justify-content-between">

                    <aside class="col-lg-3 split-sidebar">
                        <nav class="sticky-top d-none d-lg-block">
                            <ul class="nav nav-minimal flex-column" id="toc-nav">
                                <li class="nav-item">
                                    <a class="nav-link fs-lg active" href="dashboard.php">Dashboard</a>
                                </li>
                                <?php if ($select_row['done'] == 0): ?>
                                    <li class="nav-item">
                                        <a class="nav-link fs-lg" href="account-settings.php">Bio Data</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link fs-lg" href="contact-info.php">Contact Information</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link fs-lg" href="choice-prog.php">Choice of Programmes</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link fs-lg" href="examination-history.php">Examination History</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link fs-lg" href="document-upload.php">Document Upload</a>
                                    </li>
                                <?php endif; ?>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg text-red" href="sign-out.php">Sign Out</a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <div class="col-lg-9 split-content">
                        
                        <h1>Welcome, <?= ucwords($select_row['first_name']); ?>!</h1>
                        <p class="lead text-success"><span class="text-dark">Student ID:</span> <b><?= $select_row['student_id'];  ?></b></p>
                            <section>
                                <div class="row">
                                    <div class="col">
                                        <div class="card bg-secondary overflow-hidden">
                                            <div class="card-body inverted level-3">
                                                <div class="row g-3">
                                                    <div class="col-xl-8">
                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar" style="width: <?= ($select_row['done'] == 1)?'100' : '75'; ?>%;" aria-valuenow="<?= ($select_row['done'] == 1)?'100' : '75'; ?>" aria-valuemin="0" aria-valuemax="100"><?= ($select_row['done'] == 1)?'100' : '75'; ?>%</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-8">
                                                        <p class="text-secondary">
                                                            <?php if ($select_row['done'] == 1): ?>
                                                                <span class="text-info">Your completion of you admission form process is currently done. Have a sit and relax for some few days, we will verify your acount and also verify your certificate and the forms details to grant you admission to <b>University of Development Studies</b>.</span>
                                                            <?php else: ?>
                                                                Go ahead and complete your admission process by clicking on the complete admission button below...
                                                            <?php endif; ?>
                                                            </p>
                                                    </div>
                                                </div>
                                                <div class="row g-1 align-items-center mt-6">
                                                    <?php if ($select_row['done'] == 1): ?>
                                                        <div class="col-auto">
                                                            <a href="dashboard.php" class="btn btn-success rounded-pill">Admission completed</a>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="col-auto">
                                                            <a href="account-settings.php" class="btn btn-white rounded-pill">Complete Admission</a>
                                                        </div>
                                                        <div class="col-auto">
                                                            <a href="" class="btn btn-outline-white rounded-pill">Dissmiss</a>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                </div>
                                            </div>
                                            <img class="position-absolute top-0 start-100 translate-middle" src="media/pattern.svg" alt="Image">
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </section>
        </div>


<?php 
    include ("footer.php");
?>