-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2021 at 01:38 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `maame`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `fname` varchar(220) NOT NULL,
  `lname` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `password` varchar(220) NOT NULL,
  `joined_date` datetime NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `fname`, `lname`, `email`, `password`, `joined_date`, `last_login`) VALUES
(1, 'highness', 'maame', 'highness@admin.com', '$2y$10$xcbVfvPmUNURwNJWKqQY9uY/oPeXHkBo5FkYU9SBIzLcIV2y24/9C', '2021-07-21 00:26:22', '2021-09-25 12:36:11');

-- --------------------------------------------------------

--
-- Table structure for table `admissions`
--

CREATE TABLE `admissions` (
  `id` int(11) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `admission_type` varchar(220) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `nationality` varchar(200) NOT NULL,
  `religion` varchar(200) NOT NULL,
  `postal_address` text NOT NULL,
  `city` varchar(200) NOT NULL,
  `region_state` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `passport_pic` text NOT NULL,
  `vericode` varchar(50) NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `granted` tinyint(4) NOT NULL DEFAULT 0,
  `reg_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `trash` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admissions`
--

INSERT INTO `admissions` (`id`, `student_id`, `email`, `first_name`, `middle_name`, `last_name`, `password`, `admission_type`, `sex`, `dob`, `nationality`, `religion`, `postal_address`, `city`, `region_state`, `phone`, `passport_pic`, `vericode`, `verified`, `done`, `granted`, `reg_date`, `status`, `trash`) VALUES
(1, 'UDS/1630257900/21', 'tijani@gmail.com', 'tijani', '', 'moro', '$2y$10$Dqw9EnAHUhNbmw1WxfTKb.cC2f5Ef4oSbs3ZjghZCkWDM3.ZwkxEW', 'Undergraduate', 'Male', '2021-08-29', 'ghanaian', 'islam', 'AF-23423-23423', 'Kumasi', 'Ashanti', '02445111111', '612bc4c86ba346.78761185.jpg', '23b48d9222504f6c8abecd620232e225', 0, 1, 0, '2021-08-29 17:25:34', 1, 0),
(2, 'UDS/1630267020/21', 'olivia@gmail.com', 'olivia', 'afriyei', 'frimpong', '$2y$10$m9nqLsMTHqe/B0yCQhebpeSyr0K.P2ZVEjiWyOFUauMbR9PcMkVpe', 'Undergraduate', 'Female', '2021-08-29', 'ghanaian', 'christian', 'AD-5675-56', 'Accra', 'greater accra', '0222222222', '612be854965a53.37156883.png', '82ee782243607d0b623404cbd4069870', 1, 1, 0, '2021-08-29 19:57:35', 1, 0),
(3, 'UDS/1630274280/21', 'obed@gmail.com', 'enzyme', '', 'adu', '$2y$10$YbT/PSq6cra6PI7.hAYpLOpvIJKjbWzm6WRrj394b7zdWWacpkJYW', 'Postgraduate', '', '0000-00-00', '', '', '', '', '', '', '', '2a4ffef8d44b1a7740dd70ba83a552fb', 1, 1, 1, '2021-08-29 21:58:29', 1, 0),
(4, 'UDS/1630500300/21', 'henry@gmail.com', 'henry', '', 'asamoah', '$2y$10$HrYuhsu4Nq6V0QU2vXhwkuoKKimO6RAOjyi90UIx5WKdywfk0Dvlm', 'Undergraduate', 'Male', '2021-09-23', 'Ghanaian', 'Christianity', 'AF-324234-32423', 'Kumasi', 'Ashanti', '0300000000', '612f762ae0ffa2.46608420.jpg', '93a5c9241cfdf6b951a5d3773831c181', 1, 0, 0, '2021-09-01 13:45:33', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admission_details`
--

CREATE TABLE `admission_details` (
  `admission_details_id` int(11) NOT NULL,
  `admission_id` int(11) NOT NULL,
  `index_number` varchar(200) NOT NULL,
  `exams_type` varchar(500) NOT NULL,
  `school` varchar(200) NOT NULL,
  `first_cp` varchar(400) NOT NULL,
  `second_cp` varchar(400) NOT NULL,
  `third_cp` varchar(400) NOT NULL,
  `cert_info` varchar(500) NOT NULL,
  `upload_cert` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admission_details`
--

INSERT INTO `admission_details` (`admission_details_id`, `admission_id`, `index_number`, `exams_type`, `school`, `first_cp`, `second_cp`, `third_cp`, `cert_info`, `upload_cert`) VALUES
(1, 1, '', 'W A S S C E (Private)', 'Navrongo Senior High School', 'Bsc Information Technology', 'BSc Mathematics', 'BSc Statistics', 'Certificate', '612bc548b2c668.00690187.jpg'),
(2, 2, '', 'S S S C E', 'Bolgatanga Senior High School', 'BSc Computing-With-Accounting', 'BSc Environmental Science', 'BSc Geological Science', 'Certificate', '612be9e0ddab71.28957422.jpg'),
(3, 3, '', '', '', '', '', '', '', ''),
(4, 4, '', '', '', 'BSc Applied Chemistry', 'BSc Geological Science', 'BSc Applied Physics', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `examination_seating_one`
--

CREATE TABLE `examination_seating_one` (
  `id` int(11) NOT NULL,
  `admission_id` int(11) NOT NULL,
  `index_number` varchar(200) NOT NULL,
  `exams_year` int(11) DEFAULT NULL,
  `corecourse11` varchar(200) NOT NULL,
  `coreresult11` varchar(200) NOT NULL,
  `corecourse12` varchar(200) NOT NULL,
  `coreresult12` varchar(200) NOT NULL,
  `corecourse13` varchar(200) NOT NULL,
  `coreresult13` varchar(200) NOT NULL,
  `corecourse14` varchar(200) NOT NULL,
  `coreresult14` varchar(200) NOT NULL,
  `electivecourse11` varchar(200) NOT NULL,
  `electiveresult11` varchar(200) NOT NULL,
  `electivecourse12` varchar(200) NOT NULL,
  `electiveresult12` varchar(200) NOT NULL,
  `electivecourse13` varchar(200) NOT NULL,
  `electiveresult13` varchar(200) NOT NULL,
  `electivecourse14` varchar(200) NOT NULL,
  `electiveresult14` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `examination_seating_one`
--

INSERT INTO `examination_seating_one` (`id`, `admission_id`, `index_number`, `exams_year`, `corecourse11`, `coreresult11`, `corecourse12`, `coreresult12`, `corecourse13`, `coreresult13`, `corecourse14`, `coreresult14`, `electivecourse11`, `electiveresult11`, `electivecourse12`, `electiveresult12`, `electivecourse13`, `electiveresult13`, `electivecourse14`, `electiveresult14`) VALUES
(1, 1, '11111', 2019, 'Social Studies', 'B3', 'English Language', 'C5', 'Mathematics(Core)', 'C4', 'Integrated Science', 'B3', 'Animal Husbandry', 'B3', 'Geography', 'C4', 'Arabic', 'C5', 'Literature-in English', 'C4'),
(2, 2, '0101', 2007, 'Social Studies', 'A', 'English Language', 'D7', 'Mathematics(Core)', 'C5', 'Integrated Science', 'B', 'Physics', 'C4', 'Mathematics (Elective)', 'C6', 'Literature-in English', 'B3', 'History', 'D'),
(3, 3, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, 4, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `examination_seating_three`
--

CREATE TABLE `examination_seating_three` (
  `id` int(11) NOT NULL,
  `admission_id` int(11) NOT NULL,
  `s3_index_number` varchar(200) NOT NULL,
  `s3_exams_year` int(11) DEFAULT NULL,
  `s3_corecourse11` varchar(200) NOT NULL,
  `s3_coreresult11` varchar(200) NOT NULL,
  `s3_corecourse12` varchar(200) NOT NULL,
  `s3_coreresult12` varchar(200) NOT NULL,
  `s3_corecourse13` varchar(200) NOT NULL,
  `s3_coreresult13` varchar(200) NOT NULL,
  `s3_corecourse14` varchar(200) NOT NULL,
  `s3_coreresult14` varchar(200) NOT NULL,
  `s3_electivecourse11` varchar(200) NOT NULL,
  `s3_electiveresult11` varchar(200) NOT NULL,
  `s3_electivecourse12` varchar(200) NOT NULL,
  `s3_electiveresult12` varchar(200) NOT NULL,
  `s3_electivecourse13` varchar(200) NOT NULL,
  `s3_electiveresult13` varchar(200) NOT NULL,
  `s3_electivecourse14` varchar(200) NOT NULL,
  `s3_electiveresult14` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `examination_seating_three`
--

INSERT INTO `examination_seating_three` (`id`, `admission_id`, `s3_index_number`, `s3_exams_year`, `s3_corecourse11`, `s3_coreresult11`, `s3_corecourse12`, `s3_coreresult12`, `s3_corecourse13`, `s3_coreresult13`, `s3_corecourse14`, `s3_coreresult14`, `s3_electivecourse11`, `s3_electiveresult11`, `s3_electivecourse12`, `s3_electiveresult12`, `s3_electivecourse13`, `s3_electiveresult13`, `s3_electivecourse14`, `s3_electiveresult14`) VALUES
(1, 1, '33333', 2017, 'Social Studies', 'C6', 'English Language', 'C4', 'Mathematics(Core)', 'B3', 'Integrated Science', 'C4', 'Animal Husbandry', 'C4', 'Mathematics (Elective)', 'C4', 'Mathematics (Elective)', 'C5', 'History', 'C4'),
(2, 2, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 3, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, 4, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `examination_seating_two`
--

CREATE TABLE `examination_seating_two` (
  `id` int(11) NOT NULL,
  `admission_id` int(11) NOT NULL,
  `s2_index_number` varchar(200) NOT NULL,
  `s2_exams_year` int(11) DEFAULT NULL,
  `s2_corecourse11` varchar(200) NOT NULL,
  `s2_coreresult11` varchar(200) NOT NULL,
  `s2_corecourse12` varchar(200) NOT NULL,
  `s2_coreresult12` varchar(200) NOT NULL,
  `s2_corecourse13` varchar(200) NOT NULL,
  `s2_coreresult13` varchar(200) NOT NULL,
  `s2_corecourse14` varchar(200) NOT NULL,
  `s2_coreresult14` varchar(200) NOT NULL,
  `s2_electivecourse11` varchar(200) NOT NULL,
  `s2_electiveresult11` varchar(200) NOT NULL,
  `s2_electivecourse12` varchar(200) NOT NULL,
  `s2_electiveresult12` varchar(200) NOT NULL,
  `s2_electivecourse13` varchar(200) NOT NULL,
  `s2_electiveresult13` varchar(200) NOT NULL,
  `s2_electivecourse14` varchar(200) NOT NULL,
  `s2_electiveresult14` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `examination_seating_two`
--

INSERT INTO `examination_seating_two` (`id`, `admission_id`, `s2_index_number`, `s2_exams_year`, `s2_corecourse11`, `s2_coreresult11`, `s2_corecourse12`, `s2_coreresult12`, `s2_corecourse13`, `s2_coreresult13`, `s2_corecourse14`, `s2_coreresult14`, `s2_electivecourse11`, `s2_electiveresult11`, `s2_electivecourse12`, `s2_electiveresult12`, `s2_electivecourse13`, `s2_electiveresult13`, `s2_electivecourse14`, `s2_electiveresult14`) VALUES
(1, 1, '22222', 2018, 'Social Studies', 'C4', 'English Language', 'B3', 'Mathematics(Core)', 'C5', 'Integrated Science', 'C4', 'Mathematics (Elective)', 'B3', 'History', 'C4', 'Animal Husbandry', 'C6', 'Geography', 'C4'),
(2, 2, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 3, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, 4, '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `admissions`
--
ALTER TABLE `admissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `vericode` (`vericode`) USING BTREE;

--
-- Indexes for table `admission_details`
--
ALTER TABLE `admission_details`
  ADD PRIMARY KEY (`admission_details_id`);

--
-- Indexes for table `examination_seating_one`
--
ALTER TABLE `examination_seating_one`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examination_seating_three`
--
ALTER TABLE `examination_seating_three`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examination_seating_two`
--
ALTER TABLE `examination_seating_two`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admissions`
--
ALTER TABLE `admissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admission_details`
--
ALTER TABLE `admission_details`
  MODIFY `admission_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `examination_seating_one`
--
ALTER TABLE `examination_seating_one`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `examination_seating_three`
--
ALTER TABLE `examination_seating_three`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `examination_seating_two`
--
ALTER TABLE `examination_seating_two`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
