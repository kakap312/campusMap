<?php   

    require_once ("connection/conn.php");

    if (!isset($_SESSION['id'])) {
        header('Location: sign-in.php');
    }

    if ($select_row['done'] == 1) {
        header('Location: dashboard.php');
    }

    include ("head.php");

    if (isset($_POST['submit'])) {
        $first_prog = sanitize($_POST['first_prog']);
        $middle_prog = sanitize($_POST['middle_prog']);
        $last_prog = sanitize($_POST['last_prog']);

        $update_query = "
            UPDATE admission_details
            SET first_cp = :first_cp, second_cp = :second_cp, third_cp = :third_cp
            WHERE admission_id = :admission_id
        ";
        $statement = $conn->prepare($update_query);
        $result = $statement->execute([
            ':first_cp'     => $first_prog,
            ':second_cp'    => $middle_prog,
            ':third_cp'     => $last_prog,
            ':admission_id' => (int)$_SESSION['id']
        ]);

        if (isset($result)) {
            header('Location: examination-history.php');
        }
    }
?>

<body class="bg-light">

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-light bg-light border-bottom">
        <div class="container">
            <a href="account-settings.php" class="navbar-brand"><img src="media/logo-1.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>

                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#userNav"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-hover d-none d-lg-block">
                    <a class="nav-link nav-icon" role="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="account-settings.php">Bio Data</a></li>
                        <li><a class="dropdown-item " href="contact-info.php">Contact Information</a></li>
                        <li><a class="dropdown-item active" href="choice-prog.php">Choice of Programmes</a></li>
                        <li><a class="dropdown-item" href="examination-history.php">Examination History</a></li>
                        <li><a class="dropdown-item" href="document-upload.php">Document Upload</a></li>
                        <li><a class="dropdown-item text-red" href="sign-out.php">Log Out</a></li>
                    </ul>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                    aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="dashboard.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li> -->
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
    </nav>

    <div class="offcanvas-wrap">
        <section class="split">
            <div class="container">
                <div class="row justify-content-between">

                    <aside class="col-lg-3 split-sidebar">
                        <nav class="sticky-top d-none d-lg-block">
                            <ul class="nav nav-minimal flex-column" id="toc-nav">
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="dashboard.php">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="account-settings.php">Bio Data</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="contact-info.php">Contact Information</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg active" href="choice-prog.php">Choice of Programmes</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="examination-history.php">Examination History</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="document-upload.php">Document Upload</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg text-red" href="sign-out.php">Sign Out</a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <div class="col-lg-9 split-content">
                        <div class="row">
                            <div class="col-lg-10">
                                <h1>Chioce of Programme</h1>
                                <div class="alert alert-success mb-0" role="alert">
                                    Please provide your choice of programmes settings.
                                </div>
                            </div>
                        </div>

                        <section>
                            <div class="row">
                                <div class="col-lg-10">
                                    <h3 class="fs-4">Programmes</h3>
                                    <div class="card bg-opaque-white">
                                        <div class="card-body bg-white">
                                            <form class="row g-2 g-lg-3" method="POST" action="choice-prog.php">
                                                <div class="col-md-12">
                                                    <label for="first_prog" class="form-label">First Choice</label>
                                                    <select id="first_prog" class="form-control" name="first_prog" required>
                                                        <option value="">-- select your first choice --</option>
                                                        <option value="Bsc Information Technology" <?= ((isset($_POST['first_prog']) == 'Bsc Information Technology' || $select_row['first_cp'] == 'Bsc Information Technology')?'selected':''); ?>>Bsc Information Technology</option>
                                                        <option value="BSc Mathematics" <?= ((isset($_POST['first_prog']) == 'BSc Mathematics' || $select_row['first_cp'] == 'BSc Mathematics')?'selected':''); ?>>BSc Mathematics</option>
                                                        <option value="BSc Statistics" <?= ((isset($_POST['first_prog']) == 'BSc Statistics' || $select_row['first_cp'] == 'BSc Statistics')?'selected':''); ?>>BSc Statistics</option>
                                                        <option value="BSc Acturaial Sciene" <?= ((isset($_POST['first_prog']) == 'BSc Acturaial Sciene' || $select_row['first_cp'] == 'BSc Acturaial Sciene')?'selected':''); ?>>BSc Acturaial Sciene</option>
                                                        <option value="BSc Computer Science" <?= ((isset($_POST['first_prog']) == 'BSc Computer Science' || $select_row['first_cp'] == 'BSc Computer Science')?'selected':''); ?>>BSc Computer Science</option>
                                                        <option value="BSc Applied Biology" <?= ((isset($_POST['first_prog']) == 'BSc Applied Biology' || $select_row['first_cp'] == 'BSc Applied Biology')?'selected':''); ?>>BSc Applied Biology</option>
                                                        <option value="BSc Applied Physics" <?= ((isset($_POST['first_prog']) == 'BSc Applied Physics' || $select_row['first_cp'] == 'BSc Applied Physics')?'selected':''); ?>>BSc Applied Physics</option>
                                                        <option value="BSc Applied Chemistry" <?= ((isset($_POST['first_prog']) == 'BSc Applied Chemistry' || $select_row['first_cp'] == 'BSc Applied Chemistry')?'selected':''); ?>>BSc Applied Chemistry</option>
                                                        <option value="BSc Biochemistry" <?= ((isset($_POST['first_prog']) == 'BSc Biochemistry' || $select_row['first_cp'] == 'BSc Biochemistry')?'selected':''); ?>>BSc Biochemistry</option>
                                                        <option value="BEd Science" <?= ((isset($_POST['first_prog']) == 'BEd Science' || $select_row['first_cp'] == 'BEd Science')?'selected':''); ?>>BEd Science</option>
                                                        <option value="BSc Geological Science" <?= ((isset($_POST['first_prog']) == 'BSc Geological Science' || $select_row['first_cp'] == 'BSc Geological Science')?'selected':''); ?>>BSc Geological Science</option>
                                                        <option value="BSc Environmental Science" <?= ((isset($_POST['first_prog']) == 'BSc Environmental Science' || $select_row['first_cp'] == 'BSc Environmental Science')?'selected':''); ?>>BSc Environmental Science</option>
                                                        <option value="BSc Computing-With-Accounting" <?= ((isset($_POST['first_prog']) == 'BSc Computing-With-Accounting' || $select_row['first_cp'] == 'BSc Computing-With-Accounting')?'selected':''); ?>>BSc Computing-With-Accounting</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="middle_prog" class="form-label">Second Choice</label>
                                                    <select id="middle_prog" class="form-control" name="middle_prog" required>
                                                        <option value="">-- select your second choice --</option>
                                                        <option value="Bsc Information Technology" <?= ((isset($_POST['middle_prog']) == 'Bsc Information Technology' || $select_row['second_cp'] == 'Bsc Information Technology')?'selected':''); ?>>Bsc Information Technology</option>
                                                        <option value="BSc Mathematics" <?= ((isset($_POST['middle_prog']) == 'BSc Mathematics' || $select_row['second_cp'] == 'BSc Mathematics')?'selected':''); ?>>BSc Mathematics</option>
                                                        <option value="BSc Statistics" <?= ((isset($_POST['middle_prog']) == 'BSc Statistics' || $select_row['second_cp'] == 'BSc Statistics')?'selected':''); ?>>BSc Statistics</option>
                                                        <option value="BSc Acturaial Sciene" <?= ((isset($_POST['middle_prog']) == 'BSc Acturaial Sciene' || $select_row['second_cp'] == 'BSc Acturaial Sciene')?'selected':''); ?>>BSc Acturaial Sciene</option>
                                                        <option value="BSc Computer Science" <?= ((isset($_POST['middle_prog']) == 'BSc Computer Science' || $select_row['second_cp'] == 'BSc Computer Science')?'selected':''); ?>>BSc Computer Science</option>
                                                        <option value="BSc Applied Biology" <?= ((isset($_POST['middle_prog']) == 'BSc Applied Biology' || $select_row['second_cp'] == 'BSc Applied Biology')?'selected':''); ?>>BSc Applied Biology</option>
                                                        <option value="BSc Applied Physics" <?= ((isset($_POST['middle_prog']) == 'BSc Applied Physics' || $select_row['second_cp'] == 'BSc Applied Physics')?'selected':''); ?>>BSc Applied Physics</option>
                                                        <option value="BSc Applied Chemistry" <?= ((isset($_POST['middle_prog']) == 'BSc Applied Chemistry' || $select_row['second_cp'] == 'BSc Applied Chemistry')?'selected':''); ?>>BSc Applied Chemistry</option>
                                                        <option value="BSc Biochemistry" <?= ((isset($_POST['middle_prog']) == 'BSc Biochemistry' || $select_row['second_cp'] == 'BSc Biochemistry')?'selected':''); ?>>BSc Biochemistry</option>
                                                        <option value="BEd Science" <?= ((isset($_POST['middle_prog']) == 'BEd Science' || $select_row['second_cp'] == 'BEd Science')?'selected':''); ?>>BEd Science</option>
                                                        <option value="BSc Geological Science" <?= ((isset($_POST['middle_prog']) == 'BSc Geological Science' || $select_row['second_cp'] == 'BSc Geological Science')?'selected':''); ?>>BSc Geological Science</option>
                                                        <option value="BSc Environmental Science" <?= ((isset($_POST['middle_prog']) == 'BSc Environmental Science' || $select_row['second_cp'] == 'BSc Environmental Science')?'selected':''); ?>>BSc Environmental Science</option>
                                                        <option value="BSc Computing-With-Accounting" <?= ((isset($_POST['middle_prog']) == 'BSc Computing-With-Accounting' || $select_row['second_cp'] == 'BSc Computing-With-Accounting')?'selected':''); ?>>BSc Computing-With-Accounting</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="last_prog" class="form-label">Third Choice</label>
                                                    <select id="last_prog" class="form-control" name="last_prog" required>
                                                        <option value="">-- select your third choice --</option>
                                                       <option value="Bsc Information Technology" <?= ((isset($_POST['last_prog']) == 'Bsc Information Technology' || $select_row['third_cp'] == 'Bsc Information Technology')?'selected':''); ?>>Bsc Information Technology</option>
                                                        <option value="BSc Mathematics" <?= ((isset($_POST['last_prog']) == 'BSc Mathematics' || $select_row['third_cp'] == 'BSc Mathematics')?'selected':''); ?>>BSc Mathematics</option>
                                                        <option value="BSc Statistics" <?= ((isset($_POST['last_prog']) == 'BSc Statistics' || $select_row['third_cp'] == 'BSc Statistics')?'selected':''); ?>>BSc Statistics</option>
                                                        <option value="BSc Acturaial Sciene" <?= ((isset($_POST['last_prog']) == 'BSc Acturaial Sciene' || $select_row['third_cp'] == 'BSc Acturaial Sciene')?'selected':''); ?>>BSc Acturaial Sciene</option>
                                                        <option value="BSc Computer Science" <?= ((isset($_POST['last_prog']) == 'BSc Computer Science' || $select_row['third_cp'] == 'BSc Computer Science')?'selected':''); ?>>BSc Computer Science</option>
                                                        <option value="BSc Applied Biology" <?= ((isset($_POST['last_prog']) == 'BSc Applied Biology' || $select_row['third_cp'] == 'BSc Applied Biology')?'selected':''); ?>>BSc Applied Biology</option>
                                                        <option value="BSc Applied Physics" <?= ((isset($_POST['last_prog']) == 'BSc Applied Physics' || $select_row['third_cp'] == 'BSc Applied Physics')?'selected':''); ?>>BSc Applied Physics</option>
                                                        <option value="BSc Applied Chemistry" <?= ((isset($_POST['last_prog']) == 'BSc Applied Chemistry' || $select_row['third_cp'] == 'BSc Applied Chemistry')?'selected':''); ?>>BSc Applied Chemistry</option>
                                                        <option value="BSc Biochemistry" <?= ((isset($_POST['last_prog']) == 'BSc Biochemistry' || $select_row['third_cp'] == 'BSc Biochemistry')?'selected':''); ?>>BSc Biochemistry</option>
                                                        <option value="BEd Science" <?= ((isset($_POST['last_prog']) == 'BEd Science' || $select_row['third_cp'] == 'BEd Science')?'selected':''); ?>>BEd Science</option>
                                                        <option value="BSc Geological Science" <?= ((isset($_POST['last_prog']) == 'BSc Geological Science' || $select_row['third_cp'] == 'BSc Geological Science')?'selected':''); ?>>BSc Geological Science</option>
                                                        <option value="BSc Environmental Science" <?= ((isset($_POST['last_prog']) == 'BSc Environmental Science' || $select_row['third_cp'] == 'BSc Environmental Science')?'selected':''); ?>>BSc Environmental Science</option>
                                                        <option value="BSc Computing-With-Accounting" <?= ((isset($_POST['last_prog']) == 'BSc Computing-With-Accounting' || $select_row['third_cp'] == 'BSc Computing-With-Accounting')?'selected':''); ?>>BSc Computing-With-Accounting</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <button type="submit" name="submit" id="submit" class="btn btn-success">Submit Choice of Pragrammes</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

    </div>


    <?php 
        include ("footer.php");
    ?>


    <select id="first_choice" class="form-control select2 select2-hidden-accessible" name="first_choice" style="width: 100%;" required="required" tabindex="-1" aria-hidden="true">
<option></option>
<option>Bsc Information Technology</option><option>BSc Mathematics</option><option>BSc Statistics</option><option>BSc Acturaial Sciene</option><option>BSc Computer Science</option><option>BSc Applied Biology</option><option>BSc Applied Physics</option><option>BSc Applied Chemistry</option><option>Diploma in Statistics</option><option>BSc Biochemistry</option><option>BEd Science</option><option>BSc Geological Science</option><option>BSc Environmental Science</option><option>BSc Computing-With-Accounting</option><option>Diploma in Computer Science</option><option>BEd Mathematics</option><option>Diploma in Actuarial Science</option><option>Diploma in Mathematics </option><option>Diploma in Mathematics-with-Finance</option><option>Diploma in Mathematics-with-Economics</option><option>Diploma in Science Education</option><option>Diploma in Computer Science Education</option><option>Diploma in Information Technology</option><option>Diploma in Cyber and Information Security</option><option>Diploma in Mathematics Education</option><option>BSc Mathematics-with-Economics</option><option>BSc Mathematics-with-Finance</option><option>BSc Software Engineering Technology</option><option>BSc Cyber and Information Security</option><option>Diploma in Software Engineering Technology</option><option>Diploma in Business Computing</option><option>BSc Data Science</option><option>BSc Industrial Chemistry</option><option>BSc Pharmaceutical Technology</option><option>BSc Forensic Science</option><option>Diploma in Laboratory Technology</option><option>BSc Microbial Biotechnology</option><option>BSc Plant Science and Technology</option><option>BSc Animal Biodiversity and Conservation Science</option><option>BSc Geophysics</option><option>BSc Industrial Physics</option><option>BSc Medical Physics</option><option>BSc Mathematics with Computing</option><option>BSc Biostatistics</option><option>BSc Environmental and Sustainable Development</option><option>BSc Agro-meteorology and Climate Science</option> </select>