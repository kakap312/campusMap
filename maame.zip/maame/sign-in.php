<?php   

    require_once ("connection/conn.php");

    if (isset($_SESSION['id'])) {
        header('Location: dashboard.php');
    }

    include ("head.php");

    $errorMsg = '';
    if (isset($_POST['submit'])) {
        $student_id = sanitize($_POST['student_id']);
        $password = trim($_POST['password']);

        $queryS = "SELECT * FROM admissions WHERE student_id = :student_id LIMIT 1";
        $statement = $conn->prepare($queryS);
        $statement->execute([':student_id' => $student_id]);
        $count_row = $statement->rowCount();
        $result = $statement->fetchAll();

        
        if ($count_row > 0) {
            foreach ($result as $row) {
                $hashedPwdCheck = password_verify($password, $row['password']);

                if ($hashedPwdCheck == false) {
                    $errorMsg = "Invalid Details!";
                } else if ($hashedPwdCheck == true) {
                    if ($row['verified'] == 1) {
                        if (!empty($errorMsg)) {
                            $errorMsg;
                        } else {
                            $id = $row['id'];
                            $_SESSION['id'] = $id;
                            header('Location: dashboard.php');
                        }
                    } else {
                        $errorMsg = "Your account has not been verified, please check your email for the verification link.!";
                    }
                }
            }
        } else {
            $errorMsg = "Invalid Student ID!";
        }
            
    }

?>

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-dark">
        <div class="container">
            <a href="index.php" class="navbar-brand"><img src="media/logo-2.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
                <li class="nav-item d-none d-lg-block">
                    <a href="sign-in.php" class="btn btn-outline-white rounded-pill ms-2">
                        Student Portal
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="index.php" role="button">
                            Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            STAFF PORTAL
                        </a>
                    </li>
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
    </nav>

    <section class="bg-black overflow-hidden">
        <div class="py-15 py-xl-20 d-flex flex-column container level-3 min-vh-100">
            <div class="row align-items-center justify-content-center my-auto">
                <div class="col-md-10 col-lg-8 col-xl-5">

                    <div class="card">
                        <div class="card-header bg-white text-center pb-0">
                            <h5 class="fs-4 mb-1">Sign In</h5>
                            <ul style="float: left;">
                                <li class="text-danger"><?= $errorMsg; ?></li>
                            </ul>
                        </div>
                        
                        <div class="card-body bg-white">
                            <form action="sign-in.php" method="POST">
                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="student_id" name="student_id" placeholder="NCU/000000000/00" required>
                                    <label for="student_id">Student ID</label>
                                </div>
                                <div class="form-floating mb-2">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                                    <label for="password">Password</label>
                                </div>
                                <div class="d-grid mb-2">
                                    <button type="submit" name="submit" id="submit" class="btn btn-lg btn-success">Sign In</button>
                                </div>
                                <div class="row">
                                    <div class="col text-end">
                                        <!-- <a href="forgot-password.php" class="underline small">Forgot password?</a> -->
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer bg-opaque-black inverted text-center">
                            <p class="text-secondary">Don't have an account yet? <a href="index.php" class="underline">Register</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <figure class="background background-overlay" style="background-image: url('media/bg3.jpg')">
        </figure>
    </section>


<?php 
    include ("footer.php");
?>