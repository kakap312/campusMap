<?php 

	// Make Date Redable
	function pretty_date($date){
		return date("M d, Y h:i A", strtotime($date));
	}

	// Check For Incorrect Input Of Data
	function sanitize($dirty) {
		return htmlentities($dirty, ENT_QUOTES, "UTF-8");
	}
	
	// Sessions For login
	function login($madmin_id) {
		$_SESSION['adminId'] = $madmin_id;
		global $conn;
		$data = array(
			':last_login' => date("Y-m-d H:i:s"),
			':admin_id' => (int)$madmin_id
		);
		$query = "UPDATE admin SET last_login = :last_login WHERE admin_id = :admin_id";
		$statement = $conn->prepare($query);
		$result = $statement->execute($data);
		if (isset($result)) {
			$_SESSION['flash_success'] = '<div class="text-center" id="temporary">You are now logged in!</div>';
			header('Location: index.php');
		}
	}

	function is_logged_in(){
		if (isset($_SESSION['adminId']) && $_SESSION['adminId'] > 0) {
			return true;
		}
		return false;
	}

	// Redirect If not Logged in
	function login_error_redirect($url = 'login.php') {
		$_SESSION['flash_error'] = '<div class="text-center" id="temporary" style="margin-top: 60px;">Oops... you must be logged in to access that page.</div>';
		header('Location: '.$url);
	}

	function admin_permission_error_redirect($url = 'login'){
		$_SESSION['flash_error'] = '<div class="text-center" style="margin-top: 60px;">You do not have permission to that page.</div>';
		header('Location: '.$url);
	}


	////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// COUNT NUMBER OF NONE VERIFIED ACCOUNTS
	function count_none_verified_account() {
		global $conn;
		$statement = $conn->prepare("
			SELECT * FROM admissions
			WHERE verified = :verified
	        AND done = :done
	        AND granted = :granted
	        AND trash = :trash
	        ");
		$statement->execute([':verified' => 0, ':done' => 0, ':granted' => 0, ':trash' => 0]);
		return $statement->rowCount();
	}

	// COUNT NUMBER OF VERIFIED ACCOUNTS
	function count_verified_account() {
		global $conn;
		$statement = $conn->prepare("
			SELECT * FROM admissions
			WHERE verified = :verified
	        AND done = :done
	        AND granted = :granted
	        AND trash = :trash
			");
		$statement->execute([':verified' => 1, ':done' => 0, ':granted' => 0, ':trash' => 0]);
		return $statement->rowCount();
	}

	// COUNT NUMBER OF COMPLETED ADMISSION
	function count_completed_admissions() {
		global $conn;
		$statement = $conn->prepare("
			SELECT * FROM admissions
			WHERE done = :done
	        AND verified = :verified
	        AND granted = :granted
	        AND trash = :trash
			");
		$statement->execute([':done' => 1, ':verified' => 1, ':granted' => 0, ':trash' => 0]);
		return $statement->rowCount();
	}

	// COUNT NUMBER OF GRANTED ADMISSION
	function count_granted_admissions() {
		global $conn;
		$statement = $conn->prepare("
			SELECT * FROM admissions
			WHERE granted = :granted
	        AND verified = :verified
	        AND done = :done
	        AND trash = :trash
			");
		$statement->execute([':granted' => 1, ':verified' => 1, ':done' => 1, ':trash' => 0]);
		return $statement->rowCount();
	}

	// COUNT NUMBER OF GRANTED ADMISSION
	function count_fake_documents() {
		global $conn;
		$statement = $conn->prepare("
			SELECT * FROM admissions
			WHERE granted = :granted
        	AND trash = :trash
        	");
		$statement->execute([':granted' => 2, ':trash' => 0]);
		return $statement->rowCount();
	}


?>