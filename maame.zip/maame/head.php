<?php 

    // if (!isset($_SESSION)) {
    //     session_start();
    // }

    // require_once ("functions.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" >
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="media/logo-1.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/libs.bundle.css">
    <link rel="stylesheet" href="assets/css/index.bundle.css">
    <title>University For Development Studies.</title></head>

    <style>
        body {
            --bs-primary: #1d4b40;
        }

        .nav-minimal .nav-link:hover {
            color: #1d7f1d !important;
        }

        .nav-minimal .nav-link[class*="active"] {
            color: #1d7f1d !important;
        }

        .dropdown-menu .dropdown-item.active {
            color: #1d7f1d;
            background: transparent;
        }

        .dropdown-item.active, .dropdown-item:active {
            background-color: #1d7f1d;
        }
    </style>

<body>