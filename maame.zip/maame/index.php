<?php   

    require_once ("connection/conn.php");
    require "PHPMailer/PHPMailerAutoload.php";

    include ("head.php");

    $errMsg = '';
    if (isset($_POST['submit'])) {
        $email = sanitize($_POST['email']);
        $first_name = sanitize($_POST['first_name']);
        $middle_name = sanitize($_POST['middle_name']);
        $last_name = sanitize($_POST['last_name']);
        $password = $_POST['password'];
        $hash_password = password_hash($password, PASSWORD_BCRYPT);
        $admission_type = sanitize($_POST['admission_type']);

        $student_id = 'UDS/'.strtotime(date("M d, Y h:i A")).'/'.date('y');
        $activation_code = md5(rand());

        $queryS = "SELECT * FROM admissions WHERE email = :email";
        $statement = $conn->prepare($queryS);
        $statement->execute([
            ':email'        => $email
        ]);
        $count_row = $statement->rowCount();
        $result = $statement->fetchAll();

        if ($count_row != 0) {
            $errMsg = 'Your email or phone number already exist.';
        } else {

            if (strlen($password) < 6) {
                $errMsg = 'Your password  must be at least 6 characters.';
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errMsg = 'You must enter a valid email.';
            }

            if ($errMsg != '') {
                $errMsg;
            } else {

                $queryI = "
                    INSERT INTO admissions (student_id, email, first_name, middle_name, last_name, password, admission_type, vericode)
                    VALUES (:student_id, :email, :first_name, :middle_name, :last_name, :password, :admission_type, :vericode)
                ";
                $statement = $conn->prepare($queryI);
                $result = $statement->execute(
                    array(
                        ':student_id'       => $student_id,
                        ':email'            => $email,
                        ':first_name'       => $first_name,
                        ':middle_name'      => $middle_name,
                        ':last_name'        => $last_name,
                        ':password'         => $hash_password,
                        ':admission_type'   => $admission_type,
                        ':vericode'         => $activation_code
                    )
                );

                $last_id = $conn->lastInsertId();
                if (isset($result)) {
                    $query2 = "
                        INSERT INTO admission_details (admission_id)
                        VALUES (:admission_id)
                    ";
                    $statement = $conn->prepare($query2);
                    $statement->execute([':admission_id' => $last_id]);

                    $query3 = "
                        INSERT INTO examination_seating_one (admission_id)
                        VALUES (:admission_id)
                    ";
                    $statement = $conn->prepare($query3);
                    $statement->execute([':admission_id' => $last_id]);

                    $query4 = "
                        INSERT INTO examination_seating_two (admission_id)
                        VALUES (:admission_id)
                    ";
                    $statement = $conn->prepare($query4);
                    $statement->execute([':admission_id' => $last_id]);

                    $query5 = "
                        INSERT INTO examination_seating_three (admission_id)
                        VALUES (:admission_id)
                    ";
                    $statement = $conn->prepare($query5);
                    $statement->execute([':admission_id' => $last_id]);

                    $to   = $email;
                    $from = 'info@thylies.com';
                    $from_name = 'N . C . U, Ghana';
                    $subject = 'Navrongo City University.';
                    $base_url = "http://localhost/maame/";
                    $body = '<p>Dear '.ucwords($first_name).'.</p>
                            <p>You have successfully created undergraduate admission account Navrongo City University,</p>
                            <br>
                            <p><u>Your Login Details</u><br><b>STUDENT ID</b>: '.$student_id.' <br><b>PASSWORD</b>: '.$password.'</p>
                            <p>Please open the link below to verify your email address - '.$base_url.'confirm-account.php?code_activation='.$activation_code.'</p>

                            <p>Best Regards, <br> NCU</p>';

                    $mail = new PHPMailer();
                    $mail->IsSMTP();
                    $mail->SMTPAuth = true; 
                                         
                    $mail->SMTPSecure = 'ssl'; 
                    $mail->Host = 'smtp.thylies.com';
                    $mail->Port = 465;  
                    $mail->Username = 'info@thylies.com';
                    $mail->Password = 'Un0549f7d';
                                           
                    $mail->IsHTML(true);
                    $mail->WordWrap = 50;
                    $mail->From = "info@thylies.com";
                    $mail->FromName = $from_name;
                    $mail->Sender = $from;
                    $mail->AddReplyTo($from, $from_name);
                    $mail->Subject = $subject;
                    $mail->Body = $body;
                    $mail->AddAddress($to);
                    $resultMail = $mail->Send();

                    if (!$resultMail) {
                       echo "<script>alert('Please try Later, Error Occured while Processing...');</script>";
                    } else {
                        header('Location: thankyou.php?id='.$last_id.'');
                    }
                }
                
            }
        }
    }


?>

    <!-- navbar -->
    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-dark">
        <div class="container">
            <a href="index.php" class="navbar-brand"><img src="media/logo-2.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
                <li class="nav-item d-none d-lg-block">
                    <a href="sign-in.php" class="btn btn-outline-white rounded-pill ms-2">
                        Student Portal
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="index.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="programs.php" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admission_list" role="button">
                            Admission List
                        </a>
                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link" href="admin" role="button">
                            STAFF PORTAL
                        </a>
                    </li>
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
    </nav>

    <!-- header -->
    <section class="overflow-hidden bg-black" data-aos="fade-in">
        <div class="d-flex flex-column py-20 container foreground min-vh-100">
            <div class="row align-items-center justify-content-center justify-content-lg-between my-auto">
                <div class="col-md-10 col-lg-6 col-xl-5 inverted mb-5 mb-lg-0 text-center text-lg-start">
                    <h1 class="lh-sm text-white mb-4">University For Development Studies.</h1>
                    <p class="lead text-secondary mb-4">In here, is an admission registration and verification site. After the admission forms and uploading of documents an administrator will have to verify your details in order to give you admission</p>
                    <div class="d-inline-flex align-items-center mb-0">
                        <span class="fs-2 me-2 lh-1 fw-bold">4.99</span>
                        <ul class="rating text-yellow me-3 fs-5">
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                        </ul>
                    </div>
                    <small class="d-block text-muted">Based on 573282 graduates.</small>
                </div>

                <div class="col-md-10 col-lg-6 col-xl-5" data-aos="fade-up">
                    <div class="card bg-opaque-black">
                        <div class="card-body bg-white">
                            <p class="small text-secondary">Register to start admission process ...</p>
                            <ul class="errors">
                                <li class="text-danger"><?= $errMsg; ?></li>
                            </ul>
                            <form class="row g-2" method="POST" action="index.php">
                                <div class="col-lg-12">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                                        <label for="email">Email address</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Your First Name" required>
                                        <label for="first_name">First Name</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder="Your Middle Name">
                                        <label for="middle_name">Middle Name</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Your Last Name" required>
                                        <label for="last_name">Last Name</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-floating">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Your Password" required>
                                        <label for="password">Password</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="">
                                        <select class="form-control" id="admission_type" name="admission_type" required>
                                            <option value="">Admission Type</option>
                                            <option value="Undergraduate">Undergraduate</option>
                                            <option value="Postgraduate">Postgraduate</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" id="submit" name="submit" class="btn btn-green btn-lg">Start admission process</button>
                                    <div class="row pt-1">
                                        <div class="col text-end">
                                            Already registed?<a href="sign-in.php" class="underline small">Log In.</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <figure class="background background-overlay" style="background-image: url('media/bg2.jpg')"
          data-top-top="transform: scale(1);" data-top-bottom="transform: scale(1.1);"></figure>
    </section>


<?php 

    include ("footer.php");


?>