
<!doctype html>
<html lang="en">

<head>
  
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  
  <!-- Favicon -->
  <!-- <link rel="shortcut icon" href="./assets/images/favicon.ico" type="image/x-icon" /> -->
  
  <link rel="stylesheet" href="assets/css/libs.bundle.css" />
  
  <!-- Main CSS -->
  <link rel="stylesheet" href="assets/css/index.bundle.css" />
  
  <!-- Title -->
  <title>Sign In</title></head>

<body>

  <!-- navbar -->
  <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-dark">
     <div class="container">
      <a href="./index.html" class="navbar-brand"><img src="media/logo-light.svg" alt="Logo"></a>
  
      <!-- secondary -->
      <ul class="navbar-nav navbar-nav-secondary order-lg-3">
        <li class="nav-item d-lg-none">
          <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
            aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="bi bi-list"></span>
          </a>
        </li>
        <li class="nav-item d-none d-lg-block">
          <a href="https://themes.getbootstrap.com/product/cube-multipurpose-template-ui-kit/"
            class="btn btn-outline-white rounded-pill ms-2">
            Buy Cube
          </a>
        </li>
      </ul>
  
      <!-- primary -->
      <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
        <ul class="navbar-nav">
          <li class="nav-item dropdown dropdown-hover">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown-1" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Landings
            </a>
          </li>
          <li class="nav-item dropdown dropdown-hover">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown-2" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Pages
            </a>
          </li>
          <li class="nav-item dropdown dropdown-hover">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown-3" role="button" data-bs-toggle="dropdown"
              aria-expanded="false" data-bs-auto-close="outside">
              Account
            </a>
          </li>
          <li class="nav-item dropdown dropdown-hover">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown-4" role="button" data-bs-toggle="dropdown"
              aria-expanded="false" data-bs-auto-close="outside">
              Shop
            </a>
          </li>
          <li class="nav-item dropdown dropdown-hover">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown-5" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Docs
            </a>
          </li>
          <li class="nav-item d-lg-none">
            <a href="https://themes.getbootstrap.com/product/cube-multipurpose-template-ui-kit/"
              class="nav-link text-primary">Buy Cube</a>
          </li>
        </ul>
      </div>
  
  
  
      <!-- mobile user menu -->
  
  
  
  
    </div>
  </nav>
  
  


  <section class="bg-black overflow-hidden">
    <div class="py-15 py-xl-20 d-flex flex-column container level-3 min-vh-100">
      <div class="row align-items-center justify-content-center my-auto">
        <div class="col-md-10 col-lg-8 col-xl-5">

          <div class="card">
            <div class="card-header bg-white text-center pb-0">
              <h5 class="fs-4 mb-1">Reset Password</h5>
              <p class="small text-secondary">Please enter the email address associated with your account, and we'll
                send you a
                recovery link.</p>
            </div>
            <div class="card-body bg-white">
              <form action="#">
                <div class="form-floating mb-2">
                  <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                  <label for="floatingInput">Email address</label>
                </div>
                <div class="d-grid mb-2">
                  <a href="" class="btn btn-lg btn-primary">Submit</a>
                </div>
              </form>
            </div>
            <div class="card-footer bg-opaque-white inverted text-center">
              <p class="text-muted">
                <a href="sign-in.html" class="underline">Sign In</a> or
                <a href="register.html" class="underline">Register</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <figure class="background background-overlay" style="background-image: url('media/bg1.jpg')"></figure>
  </section>


  <!-- javascript -->
  <script src="assets/js/vendor.bundle.js"></script>
  <script src="assets/js/index.bundle.js"></script></body>

</html>