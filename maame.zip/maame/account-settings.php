<?php   

    require_once ("connection/conn.php");

    if (!isset($_SESSION['id'])) {
        header('Location: sign-in.php');
    }

    if ($select_row['done'] == 1) {
        header('Location: dashboard.php');
    }

    include ("head.php");

    if (isset($_POST['submit'])) {
        $first_name = sanitize($_POST['first_name']);
        $middle_name = sanitize($_POST['middle_name']);
        $last_name = sanitize($_POST['last_name']);
        $sex = sanitize($_POST['sex']);
        $dob = $_POST['dob'];
        $nationality = sanitize($_POST['nationality']);
        $religion = sanitize($_POST['religion']);

        if (isset($_POST['uploadedFile']) != '') {
            unlink($_POST['uploadedFile']);
        }

        // IMAGE
        $image_test = explode(".", $_FILES["ppic"]["name"]);
        $image_extension = end($image_test);
        $image_name = uniqid('', true).".".$image_extension;

        $update_data = array(
            ':first_name'       => $first_name,
            ':middle_name'      => $middle_name,
            ':last_name'        => $last_name,
            ':sex'              => $sex,
            ':dob'              => $dob,
            ':nationality'      => $nationality,
            ':religion'         => $religion,
            ':passport_pic'     => $select_row['passport_pic'],
            ':id'               => (int)$_SESSION['id']
        );

        if ($_FILES["ppic"]["name"] != '') {
            $location = BASEURL.'media/students/'.$image_name;
            move_uploaded_file($_FILES["ppic"]["tmp_name"], $location);

            $update_data = array(
                ':first_name'       => $first_name,
                ':middle_name'      => $middle_name,
                ':last_name'        => $last_name,
                ':sex'              => $sex,
                ':dob'              => $dob,
                ':nationality'      => $nationality,
                ':religion'         => $religion,
                ':passport_pic'     => $image_name,
                ':id'               => (int)$_SESSION['id']
            );
        }

        $update_query = "
            UPDATE admissions
            SET first_name = :first_name, middle_name = :middle_name, last_name = :last_name, sex = :sex, dob = :dob, nationality = :nationality, religion = :religion, passport_pic = :passport_pic
            WHERE id = :id
        ";
        $statement = $conn->prepare($update_query);
        $result = $statement->execute($update_data);

        if (isset($result)) {
            header('Location: contact-info.php');
        }


    }
?>

<body class="bg-light">

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-light bg-light border-bottom">
        <div class="container">
            <a href="account-settings.php" class="navbar-brand"><img src="media/logo-1.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>

                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#userNav"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-hover d-none d-lg-block">
                    <a class="nav-link nav-icon" role="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                        <li><a class="dropdown-item active" href="account-settings.php">Bio Data</a></li>
                        <li><a class="dropdown-item " href="contact-info.php">Contact Information</a></li>
                        <li><a class="dropdown-item " href="choice-prog.php">Choice of Programmes</a></li>
                        <li><a class="dropdown-item " href="examination-history.php">Examination History</a></li>
                        <li><a class="dropdown-item" href="document-upload.php">Document Upload</a></li>
                        <li><a class="dropdown-item text-red" href="sign-out.php">Log Out</a></li>
                    </ul>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                    aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="dashboard.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li> -->
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
  </nav>

    <div class="offcanvas-wrap">
        <section class="split">
            <div class="container">
                <div class="row justify-content-between">

                    <aside class="col-lg-3 split-sidebar">
                        <nav class="sticky-top d-none d-lg-block">
                            <ul class="nav nav-minimal flex-column" id="toc-nav">
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="dashboard.php">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg active" href="account-settings.php">Bio Data</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="contact-info.php">Contact Information</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="choice-prog.php">Choice of Programmes</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="document-upload.php">Document Upload</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="examination-history.php">Examination History</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg text-red" href="sign-out.php">Sign Out</a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <div class="col-lg-9 split-content">
                        <div class="row">
                            <div class="col-lg-10">
                                <h1>Bio Data</h1>
                                <div class="alert alert-success mb-0" role="alert">
                                    Please update your bio data.
                                </div>
                            </div>
                        </div>

                        <section>
                            <div class="row">
                                <div class="col-lg-10">
                                    <h3 class="fs-4">Profile</h3>
                                    <div class="card bg-opaque-white">
                                        <div class="card-body bg-white">
                                            <form class="row g-2 g-lg-3" method="POST" action="account-settings.php" enctype="multipart/form-data">
                                                <div class="col-md-12">
                                                    <label for="first_name" class="form-label">First Name</label>
                                                    <input type="text" class="form-control" id="first_name" name="first_name" 
                                                    placeholder="First Name" value="<?= ((isset($_POST['first_name']))?$_POST['first_name']:$select_row['first_name']); ?>" required>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="middle_name" class="form-label">Middle Name</label>
                                                    <input type="text" class="form-control" id="middle_name" name="middle_name" 
                                                    placeholder="Middle Name" value="<?= ((isset($_POST['middle_name']))?$_POST['middle_name']:$select_row['middle_name']); ?>">
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="last_name" class="form-label">Last Name</label>
                                                    <input type="text" class="form-control" id="last_name" name="last_name" 
                                                    placeholder="Last Name" value="<?= ((isset($_POST['last_name']))?$_POST['last_name']:$select_row['last_name']); ?>" required>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="sex" class="form-label">Sex</label>
                                                    <select id="sex" class="form-select" name="sex" required>
                                                        <option value="">Select sex</option>
                                                        <option value="Male" <?= ((isset($_POST['sex']) == 'Male' || $select_row['sex'] == 'Male')?'selected':''); ?>>Male</option>
                                                        <option value="Female" <?= ((isset($_POST['sex']) == 'Female' || $select_row['sex'] == 'Female')?'selected':''); ?>>Female</option>
                                                        <option value="Other" <?= ((isset($_POST['sex']) == 'Other' || $select_row['sex'] == 'Other')?'selected':''); ?>>Other</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="dob" class="form-label">Date of Birth</label>
                                                    <input type="date" class="form-control" id="dob" name="dob" value="<?= ((isset($_POST['dob']))?$_POST['dob']:$select_row['dob']); ?>" required>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="nationality" class="form-label">Nationality</label>
                                                    <input type="text" class="form-control" id="nationality" name="nationality" placeholder="Nationality" value="<?= ((isset($_POST['nationality']))?$_POST['nationality']:$select_row['nationality']); ?>" required>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="religion" class="form-label">Religion</label>
                                                    <input type="text" class="form-control" id="religion" name="religion" placeholder="Religion" value="<?= ((isset($_POST['religion']))?$_POST['religion']:$select_row['religion']); ?>" required>
                                                </div>
                                                <div class="col-md-12">
                                                    <?php if ($select_row['passport_pic'] == ''): ?>
                                                        <label for="ppic" class="form-label">Upload Passport Picture</label>
                                                        <input type="file" name="ppic" class="form-control" id="ppic" required>
                                                        <span id="image-holder"></span>
                                                    <?php else: ?>
                                                        <img src="media/students/<?= $select_row['passport_pic']; ?>" class="img-thumbnail" width="100" height="100">
                                                        <br>
                                                        <a href="" class="text-danger small">click to delete and change picture</a>
                                                        <input type="file" name="ppic" class="form-control" id="ppic" accept=".pdf, .jpeg, .jpg, .png, .JPG, .PNG" style="display: none;">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-12">
                                                    <button type="submit" name="submit" id="submit" class="btn btn-success">Submit Bio-data</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

    </div>


    <?php 
        include ("footer.php");
    ?>


    <script type="text/javascript">
        $(document).ready(function() {

            // Upload IMAGE Temporary
            $(document).on('change', '#ppic', function() {
                var property = document.getElementById("ppic").files[0];
                var image_name = property.name;
                var image_extension = image_name.split(".").pop().toLowerCase();

                if (jQuery.inArray(image_extension, ['jpeg', 'png', 'PNG', 'jpg']) == -1) {
                    alert("Invalid Image File");
                    $('#ppic').val('');
                }

                var image_size = property.size;
                if (image_size > 22000000) {
                    alert('Image Size Is Too Big');
                    $('#ppic').val('');
                } else {
                    var form_data = new FormData();
                    form_data.append("ppic", property);

                    $.ajax({
                        url: "temp_upload.php",
                        method: "POST",
                        data: form_data,
                        contentType: false,
                        cache: false,
                        processData: false,
                        beforeSend: function() {
                            $("#image-holder").html("<label class='text-success'>uploading ...</label>");
                        },
                        success: function(data) {
                            $("#image-holder").html(data);
                        }
                    });
                }
            });

            // Delete An Uploaded File (i.e; Temporary Uploaded But Not Posted) From Folder;
            $(document).on('click', '.removeFile', function() {
                var tempuploded_file_id = $(this).attr('id');

                $.ajax ({
                    url: "delete_temp.php",
                    method: "POST",
                    data: {tempuploded_file_id : tempuploded_file_id},
                    success: function(data) {
                        $('#ppic').val('');
                        $('#tu_file').remove();
                    }
                });
            });

        });
    </script>