    <!-- javascript -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/vendor.bundle.js"></script>
    <script src="assets/js/index.bundle.js"></script>
    <script src="assets/js/popper.min.js"></script>
</body>
</html>