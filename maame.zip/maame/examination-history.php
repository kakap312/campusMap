<?php   

    require_once ("connection/conn.php");

    if (!isset($_SESSION['id'])) {
        header('Location: sign-in.php');
    }

    if ($select_row['done'] == 1) {
        header('Location: dashboard.php');
    }

    include ("head.php");

    if (isset($_POST['submit'])) {
        $query1 = "
            UPDATE `examination_seating_one`
            SET index_number = :index_number, exams_year = :exams_year, corecourse11 = :corecourse11, coreresult11 = :coreresult11, corecourse12 = :corecourse12, coreresult12 = :coreresult12, corecourse13 = :corecourse13, coreresult13 = :coreresult13, corecourse14 = :corecourse14, coreresult14 = :coreresult14, electivecourse11 = :electivecourse11, electiveresult11 = :electiveresult11, electivecourse12 = :electivecourse12, electiveresult12 = :electiveresult12, electivecourse13 =:electivecourse13, electiveresult13 = :electiveresult13, electivecourse14 = :electivecourse14, electiveresult14 = :electiveresult14
            WHERE admission_id = :admission_id
        ";
        $statement = $conn->prepare($query1);
        $result1 = $statement->execute([
            ':index_number' => sanitize($_POST['index_number']),
            ':exams_year' => sanitize($_POST['exams_year']),
            ':corecourse11' => sanitize($_POST['corecourse11']),
            ':coreresult11' => sanitize($_POST['coreresult11']),
            ':corecourse12' => sanitize($_POST['corecourse12']),
            ':coreresult12' => sanitize($_POST['coreresult12']),
            ':corecourse13' => sanitize($_POST['corecourse13']),
            ':coreresult13' => sanitize($_POST['coreresult13']),
            ':corecourse14' => sanitize($_POST['corecourse14']),
            ':coreresult14' => sanitize($_POST['coreresult14']),
            ':electivecourse11' => sanitize($_POST['electivecourse11']),
            ':electiveresult11' => sanitize($_POST['electiveresult11']),
            ':electivecourse12' => sanitize($_POST['electivecourse12']),
            ':electiveresult12' => sanitize($_POST['electiveresult12']),
            ':electivecourse13' => sanitize($_POST['electivecourse13']),
            ':electiveresult13' => sanitize($_POST['electiveresult13']),
            ':electivecourse14' => sanitize($_POST['electivecourse14']),
            ':electiveresult14' => sanitize($_POST['electiveresult14']),
            ':admission_id' => (int)$_SESSION['id']
        ]);

        if (isset($result1)) {
            if (!empty($_POST['s2_index_number'])) {
                $query2 = "
                    UPDATE `examination_seating_two`
                    SET s2_index_number = :s2_index_number, s2_exams_year = :s2_exams_year, s2_corecourse11 = :s2_corecourse11, s2_coreresult11 = :s2_coreresult11, s2_corecourse12 = :s2_corecourse12, s2_coreresult12 = :s2_coreresult12, s2_corecourse13 = :s2_corecourse13, s2_coreresult13 = :s2_coreresult13, s2_corecourse14 = :s2_corecourse14, s2_coreresult14 = :s2_coreresult14, s2_electivecourse11 = :s2_electivecourse11, s2_electiveresult11 = :s2_electiveresult11, s2_electivecourse12 = :s2_electivecourse12, s2_electiveresult12 = :s2_electiveresult12, s2_electivecourse13 =:s2_electivecourse13, s2_electiveresult13 = :s2_electiveresult13, s2_electivecourse14 = :s2_electivecourse14, s2_electiveresult14 = :s2_electiveresult14
                    WHERE admission_id = :admission_id
                ";
                $statement = $conn->prepare($query2);
                $result2 = $statement->execute([
                    ':s2_index_number' => sanitize($_POST['s2_index_number']),
                    ':s2_exams_year' => sanitize($_POST['s2_exams_year']),
                    ':s2_corecourse11' => sanitize($_POST['s2_corecourse11']),
                    ':s2_coreresult11' => sanitize($_POST['s2_coreresult11']),
                    ':s2_corecourse12' => sanitize($_POST['s2_corecourse12']),
                    ':s2_coreresult12' => sanitize($_POST['s2_coreresult12']),
                    ':s2_corecourse13' => sanitize($_POST['s2_corecourse13']),
                    ':s2_coreresult13' => sanitize($_POST['s2_coreresult13']),
                    ':s2_corecourse14' => sanitize($_POST['s2_corecourse14']),
                    ':s2_coreresult14' => sanitize($_POST['s2_coreresult14']),
                    ':s2_electivecourse11' => sanitize($_POST['s2_electivecourse11']),
                    ':s2_electiveresult11' => sanitize($_POST['s2_electiveresult11']),
                    ':s2_electivecourse12' => sanitize($_POST['s2_electivecourse12']),
                    ':s2_electiveresult12' => sanitize($_POST['s2_electiveresult12']),
                    ':s2_electivecourse13' => sanitize($_POST['s2_electivecourse13']),
                    ':s2_electiveresult13' => sanitize($_POST['s2_electiveresult13']),
                    ':s2_electivecourse14' => sanitize($_POST['s2_electivecourse14']),
                    ':s2_electiveresult14' => sanitize($_POST['s2_electiveresult14']),
                    ':admission_id' => (int)$_SESSION['id']
                ]);

                if (isset($result2)) {
                    if (!empty($_POST['s3_index_number'])) {
                        $query2 = "
                            UPDATE `examination_seating_three`
                            SET s3_index_number = :s3_index_number, s3_exams_year = :s3_exams_year, s3_corecourse11 = :s3_corecourse11, s3_coreresult11 = :s3_coreresult11, s3_corecourse12 = :s3_corecourse12, s3_coreresult12 = :s3_coreresult12, s3_corecourse13 = :s3_corecourse13, s3_coreresult13 = :s3_coreresult13, s3_corecourse14 = :s3_corecourse14, s3_coreresult14 = :s3_coreresult14, s3_electivecourse11 = :s3_electivecourse11, s3_electiveresult11 = :s3_electiveresult11, s3_electivecourse12 = :s3_electivecourse12, s3_electiveresult12 = :s3_electiveresult12, s3_electivecourse13 =:s3_electivecourse13, s3_electiveresult13 = :s3_electiveresult13, s3_electivecourse14 = :s3_electivecourse14, s3_electiveresult14 = :s3_electiveresult14
                            WHERE admission_id = :admission_id
                        ";
                        $statement = $conn->prepare($query2);
                        $result3 = $statement->execute([
                            ':s3_index_number' => sanitize($_POST['s3_index_number']),
                            ':s3_exams_year' => sanitize($_POST['s3_exams_year']),
                            ':s3_corecourse11' => sanitize($_POST['s3_corecourse11']),
                            ':s3_coreresult11' => sanitize($_POST['s3_coreresult11']),
                            ':s3_corecourse12' => sanitize($_POST['s3_corecourse12']),
                            ':s3_coreresult12' => sanitize($_POST['s3_coreresult12']),
                            ':s3_corecourse13' => sanitize($_POST['s3_corecourse13']),
                            ':s3_coreresult13' => sanitize($_POST['s3_coreresult13']),
                            ':s3_corecourse14' => sanitize($_POST['s3_corecourse14']),
                            ':s3_coreresult14' => sanitize($_POST['s3_coreresult14']),
                            ':s3_electivecourse11' => sanitize($_POST['s3_electivecourse11']),
                            ':s3_electiveresult11' => sanitize($_POST['s3_electiveresult11']),
                            ':s3_electivecourse12' => sanitize($_POST['s3_electivecourse12']),
                            ':s3_electiveresult12' => sanitize($_POST['s3_electiveresult12']),
                            ':s3_electivecourse13' => sanitize($_POST['s3_electivecourse13']),
                            ':s3_electiveresult13' => sanitize($_POST['s3_electiveresult13']),
                            ':s3_electivecourse14' => sanitize($_POST['s3_electivecourse14']),
                            ':s3_electiveresult14' => sanitize($_POST['s3_electiveresult14']),
                            ':admission_id' => (int)$_SESSION['id']
                        ]);
                    }
                }
            }
            header('Location: document-upload.php');
        }
    }
?>

<body class="bg-light">

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-light bg-light border-bottom">
        <div class="container">
            <a href="account-settings.php" class="navbar-brand"><img src="media/logo-1.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>

                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#userNav"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-hover d-none d-lg-block">
                    <a class="nav-link nav-icon" role="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="account-settings.php">Bio Data</a></li>
                        <li><a class="dropdown-item " href="contact-info.php">Contact Information</a></li>
                        <li><a class="dropdown-item" href="choice-prog.php">Choice of Programmes</a></li>
                        <li><a class="dropdown-item active" href="examination-history.php">Examination History</a></li>
                        <li><a class="dropdown-item" href="document-upload.php">Document Upload</a></li>
                        <li><a class="dropdown-item text-red" href="sign-out.php">Log Out</a></li>
                    </ul>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                    aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="dashboard.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li> -->
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
    </nav>

    <div class="offcanvas-wrap">
        <section class="split">
            <div class="container">
                <div class="row justify-content-between">

                    <aside class="col-lg-3 split-sidebar">
                        <nav class="sticky-top d-none d-lg-block">
                            <ul class="nav nav-minimal flex-column" id="toc-nav">
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="dashboard.php">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="account-settings.php">Bio Data</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="contact-info.php">Contact Information</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="choice-prog.php">Choice of Programmes</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg active" href="examination-history.php">Examination History</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="document-upload.php">Document Upload</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg text-red" href="sign-out.php">Sign Out</a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <div class="col-lg-9 split-content">
                        <div class="row">
                            <div class="col-lg-10">
                                <h1>Examination History</h1>
                                <div class="alert alert-success mb-0" role="alert">
                                    Please provide your examination history below.
                                </div>
                            </div>
                        </div>

                        <section>
                            <div class="row">
                                <div class="col-lg-10">
                                    <h3 class="fs-4">Examinations</h3>
                                    <div class="card bg-opaque-white">
                                        <div class="card-body bg-white">
                                            <form class="row g-2 g-lg-3" method="POST" action="examination-history.php">
                                                <h6>Examination seating 1</h6>
                                                <div class="col-md-12">
                                                    <label for="index_number" class="form-label">Index Number</label>
                                                    <input type="text" class="form-control" id="index_number" name="index_number" placeholder="Index Number" value="<?= ((isset($_POST['index_number']))?$_POST['index_number']:''); ?>" required>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="exams_year" class="form-label">Examination Year</label>
                                                    <select id="exams_year" class="form-select" name="exams_year" required>
                                                        <option value>Select Year</option>
                                                        <option value="2020" <?= ((isset($_POST['exams_year']) == '2020')?'selected':''); ?>>2020</option>
                                                        <option value="2019" <?= ((isset($_POST['exams_year']) == '2019')?'selected':''); ?>>2019</option>
                                                        <option value="2018" <?= ((isset($_POST['exams_year']) == '2018')?'selected':''); ?>>2018</option>
                                                        <option value="2017" <?= ((isset($_POST['exams_year']) == '2017')?'selected':''); ?>>2017</option>
                                                        <option value="2016" <?= ((isset($_POST['exams_year']) == '2016')?'selected':''); ?>>2016</option>
                                                        <option value="2015" <?= ((isset($_POST['exams_year']) == '2015')?'selected':''); ?>>2015</option>
                                                        <option value="2014" <?= ((isset($_POST['exams_year']) == '2014')?'selected':''); ?>>2014</option>
                                                        <option value="2013" <?= ((isset($_POST['exams_year']) == '2013')?'selected':''); ?>>2013</option>
                                                        <option value="2012" <?= ((isset($_POST['exams_year']) == '2012')?'selected':''); ?>>2012</option>
                                                        <option value="2011" <?= ((isset($_POST['exams_year']) == '2011')?'selected':''); ?>>2011</option>
                                                        <option value="2010" <?= ((isset($_POST['exams_year']) == '2010')?'selected':''); ?>>2010</option>
                                                        <option value="2009" <?= ((isset($_POST['exams_year']) == '2009')?'selected':''); ?>>2009</option>
                                                        <option value="2008" <?= ((isset($_POST['exams_year']) == '2008')?'selected':''); ?>>2008</option>
                                                        <option value="2007" <?= ((isset($_POST['exams_year']) == '2007')?'selected':''); ?>>2007</option>
                                                        <option value="2006" <?= ((isset($_POST['exams_year']) == '2006')?'selected':''); ?>>2006</option>
                                                        <option value="2005" <?= ((isset($_POST['exams_year']) == '2005')?'selected':''); ?>>2005</option>
                                                        <option value="2004" <?= ((isset($_POST['exams_year']) == '2004')?'selected':''); ?>>2004</option>
                                                        <option value="2003" <?= ((isset($_POST['exams_year']) == '2003')?'selected':''); ?>>2003</option>
                                                        <option value="2002" <?= ((isset($_POST['exams_year']) == '2002')?'selected':''); ?>>2002</option>
                                                        <option value="2001" <?= ((isset($_POST['exams_year']) == '2001')?'selected':''); ?>>2001</option>
                                                        <option value="2000" <?= ((isset($_POST['exams_year']) == '2000')?'selected':''); ?>>2000</option>
                                                    </select>
                                                    <small class="text-danger">NB: Choose the appropriate examination year please.</small>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-sm">
                                                            <thead>
                                                                <tr>
                                                                    <th>Suject</th>
                                                                    <th>Result</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>Social Studies</td>
                                                                    <input type="hidden" name="corecourse11" value="Social Studies">
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="coreresult11" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                 </tr>
                                                                <tr>
                                                                    <td>English Language</td>
                                                                    <input type="hidden" name="corecourse12" value="English Language">
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="coreresult12" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Mathematics(Core)</td>
                                                                    <input type="hidden" name="corecourse13" value="Mathematics(Core)">
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="coreresult13" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Integrated Science</td>
                                                                    <input type="hidden" name="corecourse14" value="Integrated Science">
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="coreresult14" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2"><b>Choose Electives and results</b></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2" name="electivecourse11" required>
                                                                            <option>Choose Subject</option>
                                                                            <option value="General Agriculture">General Agriculture</option>
                                                                            <option value="Animal Husbandry">Animal Husbandry </option>
                                                                            <option value="Physics">Physics</option>
                                                                            <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                            <option value="Geography">Geography</option>
                                                                            <option value="Music">Music</option>
                                                                            <option value="ICT (Elective)">ICT (Elective)</option>
                                                                            <option value="Business Management">Business Management</option>
                                                                            <option value="French">French</option>
                                                                            <option value="Management-In-Living">Management-In-Living</option>
                                                                            <option value="Sculpture">Sculpture</option>
                                                                            <option value="Literature-in English">Literature-in English</option>
                                                                            <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                            <option value="Arabic">Arabic</option>
                                                                            <option value="Government">Government</option>
                                                                            <option value="History">History </option>
                                                                            <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                            <option value="Ewe">Ewe</option>
                                                                            <option value="Ga">Ga</option>
                                                                            <option value="Gonja">Gonja</option>
                                                                            <option value="Kasem">Kasem</option>
                                                                            <option value="Nzema">Nzema</option>
                                                                            <option value="Twi (Asante)">Twi (Asante)</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="electiveresult11" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr><tr>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2" name="electivecourse12" required>
                                                                            <option>Choose Subject</option>
                                                                            <option value="General Agriculture">General Agriculture</option>
                                                                            <option value="Animal Husbandry">Animal Husbandry </option>
                                                                            <option value="Physics">Physics</option>
                                                                            <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                            <option value="Geography">Geography</option>
                                                                            <option value="Music">Music</option>
                                                                            <option value="ICT (Elective)">ICT (Elective)</option>
                                                                            <option value="Business Management">Business Management</option>
                                                                            <option value="French">French</option>
                                                                            <option value="Management-In-Living">Management-In-Living</option>
                                                                            <option value="Sculpture">Sculpture</option>
                                                                            <option value="Literature-in English">Literature-in English</option>
                                                                            <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                            <option value="Arabic">Arabic</option>
                                                                            <option value="Government">Government</option>
                                                                            <option value="History">History </option>
                                                                            <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                            <option value="Ewe">Ewe</option>
                                                                            <option value="Ga">Ga</option>
                                                                            <option value="Gonja">Gonja</option>
                                                                            <option value="Kasem">Kasem</option>
                                                                            <option value="Nzema">Nzema</option>
                                                                            <option value="Twi (Asante)">Twi (Asante)</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="electiveresult12" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr><tr>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2" name="electivecourse13" required>
                                                                            <option>Choose Subject</option>
                                                                            <option value="General Agriculture">General Agriculture</option>
                                                                            <option value="Animal Husbandry">Animal Husbandry </option>
                                                                            <option value="Physics">Physics</option>
                                                                            <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                            <option value="Geography">Geography</option>
                                                                            <option value="Music">Music</option>
                                                                            <option value="ICT (Elective)">ICT (Elective)</option>
                                                                            <option value="Business Management">Business Management</option>
                                                                            <option value="French">French</option>
                                                                            <option value="Management-In-Living">Management-In-Living</option>
                                                                            <option value="Sculpture">Sculpture</option>
                                                                            <option value="Literature-in English">Literature-in English</option>
                                                                            <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                            <option value="Arabic">Arabic</option>
                                                                            <option value="Government">Government</option>
                                                                            <option value="History">History </option>
                                                                            <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                            <option value="Ewe">Ewe</option>
                                                                            <option value="Ga">Ga</option>
                                                                            <option value="Gonja">Gonja</option>
                                                                            <option value="Kasem">Kasem</option>
                                                                            <option value="Nzema">Nzema</option>
                                                                            <option value="Twi (Asante)">Twi (Asante)</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="electiveresult13" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2" name="electivecourse14" required>
                                                                            <option value="">Choose Subject</option>
                                                                            <option value="General Agriculture">General Agriculture</option>
                                                                            <option value="Animal Husbandry">Animal Husbandry </option>
                                                                            <option value="Physics">Physics</option>
                                                                            <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                            <option value="Geography">Geography</option>
                                                                            <option value="Music">Music</option>
                                                                            <option value="ICT (Elective)">ICT (Elective)</option>
                                                                            <option value="Business Management">Business Management</option>
                                                                            <option value="French">French</option>
                                                                            <option value="Management-In-Living">Management-In-Living</option>
                                                                            <option value="Sculpture">Sculpture</option>
                                                                            <option value="Literature-in English">Literature-in English</option>
                                                                            <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                            <option value="Arabic">Arabic</option>
                                                                            <option value="Government">Government</option>
                                                                            <option value="History">History </option>
                                                                            <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                            <option value="Ewe">Ewe</option>
                                                                            <option value="Ga">Ga</option>
                                                                            <option value="Gonja">Gonja</option>
                                                                            <option value="Kasem">Kasem</option>
                                                                            <option value="Nzema">Nzema</option>
                                                                            <option value="Twi (Asante)">Twi (Asante)</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="electiveresult14" required>
                                                                            <option></option>
                                                                            <option value="A1">A1</option>
                                                                            <option value="B2">B2</option>
                                                                            <option value="B3">B3</option>
                                                                            <option value="C4">C4</option>
                                                                            <option value="C5">C5</option>
                                                                            <option value="C6">C6</option>
                                                                            <option value="D7">D7</option>
                                                                            <option value="E8">E8</option>
                                                                            <option value="F9">F9</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                            <option value="D">D</option>
                                                                            <option value="E">E</option>
                                                                            <option value="F">F</option>
                                                                            <option>Awaiting Results</option>
                                                                        </select>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>




                                                <br>
                                                <button class="btn btn-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#seating_two" aria-expanded="false" aria-controls="seating_two">Seating Two</button>
                                                <div class="collapse" id="seating_two">
                                                   <h6>Examination seating 2</h6>
                                                    <div class="col-md-12">
                                                        <label for="s2_index_number" class="form-label">Index Number</label>
                                                        <input type="text" class="form-control" id="s2_index_number" name="s2_index_number" placeholder="Index Number" value="<?= ((isset($_POST['s2_index_number']))?$_POST['s2_index_number']:''); ?>">
                                                    </div>
                                                    <div class="col-md-12">
                                                        <label for="s2_exams_year" class="form-label">Examination Year</label>
                                                        <select id="s2_exams_year" class="form-select" name="s2_exams_year">
                                                            <option value>Select Year</option>
                                                            <option value="2020" <?= ((isset($_POST['s2_exams_year']) == '2020')?'selected':''); ?>>2020</option>
                                                            <option value="2019" <?= ((isset($_POST['s2_exams_year']) == '2019')?'selected':''); ?>>2019</option>
                                                            <option value="2018" <?= ((isset($_POST['s2_exams_year']) == '2018')?'selected':''); ?>>2018</option>
                                                            <option value="2017" <?= ((isset($_POST['s2_exams_year']) == '2017')?'selected':''); ?>>2017</option>
                                                            <option value="2016" <?= ((isset($_POST['s2_exams_year']) == '2016')?'selected':''); ?>>2016</option>
                                                            <option value="2015" <?= ((isset($_POST['s2_exams_year']) == '2015')?'selected':''); ?>>2015</option>
                                                            <option value="2014" <?= ((isset($_POST['s2_exams_year']) == '2014')?'selected':''); ?>>2014</option>
                                                            <option value="2013" <?= ((isset($_POST['s2_exams_year']) == '2013')?'selected':''); ?>>2013</option>
                                                            <option value="2012" <?= ((isset($_POST['s2_exams_year']) == '2012')?'selected':''); ?>>2012</option>
                                                            <option value="2011" <?= ((isset($_POST['s2_exams_year']) == '2011')?'selected':''); ?>>2011</option>
                                                            <option value="2010" <?= ((isset($_POST['s2_exams_year']) == '2010')?'selected':''); ?>>2010</option>
                                                            <option value="2009" <?= ((isset($_POST['s2_exams_year']) == '2009')?'selected':''); ?>>2009</option>
                                                            <option value="2008" <?= ((isset($_POST['s2_exams_year']) == '2008')?'selected':''); ?>>2008</option>
                                                            <option value="2007" <?= ((isset($_POST['s2_exams_year']) == '2007')?'selected':''); ?>>2007</option>
                                                            <option value="2006" <?= ((isset($_POST['s2_exams_year']) == '2006')?'selected':''); ?>>2006</option>
                                                            <option value="2005" <?= ((isset($_POST['s2_exams_year']) == '2005')?'selected':''); ?>>2005</option>
                                                            <option value="2004" <?= ((isset($_POST['s2_exams_year']) == '2004')?'selected':''); ?>>2004</option>
                                                            <option value="2003" <?= ((isset($_POST['s2_exams_year']) == '2003')?'selected':''); ?>>2003</option>
                                                            <option value="2002" <?= ((isset($_POST['s2_exams_year']) == '2002')?'selected':''); ?>>2002</option>
                                                            <option value="2001" <?= ((isset($_POST['s2_exams_year']) == '2001')?'selected':''); ?>>2001</option>
                                                            <option value="2000" <?= ((isset($_POST['s2_exams_year']) == '2000')?'selected':''); ?>>2000</option>
                                                        </select>
                                                        <small class="text-danger">NB: Choose the appropriate examination year please.</small>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="table-responsive">
                                                            <table class="table table-sm">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Suject</th>
                                                                        <th>Result</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr>
                                                                        <td>Social Studies</td>
                                                                        <input type="hidden" name="s2_corecourse11" value="Social Studies">
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_coreresult11" >
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                     </tr>
                                                                    <tr>
                                                                        <td>English Language</td>
                                                                        <input type="hidden" name="s2_corecourse12" value="English Language">
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_coreresult12" >
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Mathematics(Core)</td>
                                                                        <input type="hidden" name="s2_corecourse13" value="Mathematics(Core)">
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_coreresult13" >
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Integrated Science</td>
                                                                        <input type="hidden" name="s2_corecourse14" value="Integrated Science">
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_coreresult14" >
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="2"><b>Choose Electives and results</b></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2" name="s2_electivecourse11">
                                                                                <option>Choose Subject</option>
                                                                                <option value="General Agriculture">General Agriculture</option>
                                                                                <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                <option value="Physics">Physics</option>
                                                                                <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                <option value="Geography">Geography</option>
                                                                                <option value="Music">Music</option>
                                                                                <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                <option value="Business Management">Business Management</option>
                                                                                <option value="French">French</option>
                                                                                <option value="Management-In-Living">Management-In-Living</option>
                                                                                <option value="Sculpture">Sculpture</option>
                                                                                <option value="Literature-in English">Literature-in English</option>
                                                                                <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                <option value="Arabic">Arabic</option>
                                                                                <option value="Government">Government</option>
                                                                                <option value="History">History </option>
                                                                                <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                <option value="Ewe">Ewe</option>
                                                                                <option value="Ga">Ga</option>
                                                                                <option value="Gonja">Gonja</option>
                                                                                <option value="Kasem">Kasem</option>
                                                                                <option value="Nzema">Nzema</option>
                                                                                <option value="Twi (Asante)">Twi (Asante)</option>
                                                                            </select>
                                                                        </td>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_electiveresult11" >
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr><tr>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2" name="s2_electivecourse12">
                                                                                <option>Choose Subject</option>
                                                                                <option value="General Agriculture">General Agriculture</option>
                                                                                <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                <option value="Physics">Physics</option>
                                                                                <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                <option value="Geography">Geography</option>
                                                                                <option value="Music">Music</option>
                                                                                <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                <option value="Business Management">Business Management</option>
                                                                                <option value="French">French</option>
                                                                                <option value="Management-In-Living">Management-In-Living</option>
                                                                                <option value="Sculpture">Sculpture</option>
                                                                                <option value="Literature-in English">Literature-in English</option>
                                                                                <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                <option value="Arabic">Arabic</option>
                                                                                <option value="Government">Government</option>
                                                                                <option value="History">History </option>
                                                                                <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                <option value="Ewe">Ewe</option>
                                                                                <option value="Ga">Ga</option>
                                                                                <option value="Gonja">Gonja</option>
                                                                                <option value="Kasem">Kasem</option>
                                                                                <option value="Nzema">Nzema</option>
                                                                                <option value="Twi (Asante)">Twi (Asante)</option>
                                                                            </select>
                                                                        </td>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_electiveresult12">
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr><tr>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2" name="s2_electivecourse13">
                                                                                <option>Choose Subject</option>
                                                                                <option value="General Agriculture">General Agriculture</option>
                                                                                <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                <option value="Physics">Physics</option>
                                                                                <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                <option value="Geography">Geography</option>
                                                                                <option value="Music">Music</option>
                                                                                <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                <option value="Business Management">Business Management</option>
                                                                                <option value="French">French</option>
                                                                                <option value="Management-In-Living">Management-In-Living</option>
                                                                                <option value="Sculpture">Sculpture</option>
                                                                                <option value="Literature-in English">Literature-in English</option>
                                                                                <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                <option value="Arabic">Arabic</option>
                                                                                <option value="Government">Government</option>
                                                                                <option value="History">History </option>
                                                                                <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                <option value="Ewe">Ewe</option>
                                                                                <option value="Ga">Ga</option>
                                                                                <option value="Gonja">Gonja</option>
                                                                                <option value="Kasem">Kasem</option>
                                                                                <option value="Nzema">Nzema</option>
                                                                                <option value="Twi (Asante)">Twi (Asante)</option>
                                                                            </select>
                                                                        </td>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_electiveresult13">
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2" name="s2_electivecourse14">
                                                                                <option>Choose Subject</option>
                                                                                <option value="General Agriculture">General Agriculture</option>
                                                                                <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                <option value="Physics">Physics</option>
                                                                                <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                <option value="Geography">Geography</option>
                                                                                <option value="Music">Music</option>
                                                                                <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                <option value="Business Management">Business Management</option>
                                                                                <option value="French">French</option>
                                                                                <option value="Management-In-Living">Management-In-Living</option>
                                                                                <option value="Sculpture">Sculpture</option>
                                                                                <option value="Literature-in English">Literature-in English</option>
                                                                                <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                <option value="Arabic">Arabic</option>
                                                                                <option value="Government">Government</option>
                                                                                <option value="History">History </option>
                                                                                <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                <option value="Ewe">Ewe</option>
                                                                                <option value="Ga">Ga</option>
                                                                                <option value="Gonja">Gonja</option>
                                                                                <option value="Kasem">Kasem</option>
                                                                                <option value="Nzema">Nzema</option>
                                                                                <option value="Twi (Asante)">Twi (Asante)</option>
                                                                            </select>
                                                                        </td>
                                                                        <td>
                                                                            <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s2_electiveresult14">
                                                                                <option></option>
                                                                                <option value="A1">A1</option>
                                                                                <option value="B2">B2</option>
                                                                                <option value="B3">B3</option>
                                                                                <option value="C4">C4</option>
                                                                                <option value="C5">C5</option>
                                                                                <option value="C6">C6</option>
                                                                                <option value="D7">D7</option>
                                                                                <option value="E8">E8</option>
                                                                                <option value="F9">F9</option>
                                                                                <option value="A">A</option>
                                                                                <option value="B">B</option>
                                                                                <option value="C">C</option>
                                                                                <option value="D">D</option>
                                                                                <option value="E">E</option>
                                                                                <option value="F">F</option>
                                                                                <option>Awaiting Results</option>
                                                                            </select>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>


                                                    <br>
                                                    <button class="btn btn-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#seating_three" aria-expanded="false" aria-controls="seating_three">Seating Three</button>
                                                    <div class="collapse" id="seating_three">
                                                       <h6>Examination seating 3</h6>
                                                        <div class="col-md-12">
                                                            <label for="s3_index_number" class="form-label">Index Number</label>
                                                            <input type="text" class="form-control" id="s3_index_number" name="s3_index_number" placeholder="Index Number" value="<?= ((isset($_POST['s3_index_number']))?$_POST['s3_index_number']:''); ?>">
                                                        </div>
                                                        <div class="col-md-12">
                                                            <label for="s3_exams_year" class="form-label">Examination Year</label>
                                                            <select id="s3_exams_year" class="form-select" name="s3_exams_year">
                                                                <option value>Select Year</option>
                                                                <option value="2020" <?= ((isset($_POST['s3_exams_year']) == '2020')?'selected':''); ?>>2020</option>
                                                                <option value="2019" <?= ((isset($_POST['s3_exams_year']) == '2019')?'selected':''); ?>>2019</option>
                                                                <option value="2018" <?= ((isset($_POST['s3_exams_year']) == '2018')?'selected':''); ?>>2018</option>
                                                                <option value="2017" <?= ((isset($_POST['s3_exams_year']) == '2017')?'selected':''); ?>>2017</option>
                                                                <option value="2016" <?= ((isset($_POST['s3_exams_year']) == '2016')?'selected':''); ?>>2016</option>
                                                                <option value="2015" <?= ((isset($_POST['s3_exams_year']) == '2015')?'selected':''); ?>>2015</option>
                                                                <option value="2014" <?= ((isset($_POST['s3_exams_year']) == '2014')?'selected':''); ?>>2014</option>
                                                                <option value="2013" <?= ((isset($_POST['s3_exams_year']) == '2013')?'selected':''); ?>>2013</option>
                                                                <option value="2012" <?= ((isset($_POST['s3_exams_year']) == '2012')?'selected':''); ?>>2012</option>
                                                                <option value="2011" <?= ((isset($_POST['s3_exams_year']) == '2011')?'selected':''); ?>>2011</option>
                                                                <option value="2010" <?= ((isset($_POST['s3_exams_year']) == '2010')?'selected':''); ?>>2010</option>
                                                                <option value="2009" <?= ((isset($_POST['s3_exams_year']) == '2009')?'selected':''); ?>>2009</option>
                                                                <option value="2008" <?= ((isset($_POST['s3_exams_year']) == '2008')?'selected':''); ?>>2008</option>
                                                                <option value="2007" <?= ((isset($_POST['s3_exams_year']) == '2007')?'selected':''); ?>>2007</option>
                                                                <option value="2006" <?= ((isset($_POST['s3_exams_year']) == '2006')?'selected':''); ?>>2006</option>
                                                                <option value="2005" <?= ((isset($_POST['s3_exams_year']) == '2005')?'selected':''); ?>>2005</option>
                                                                <option value="2004" <?= ((isset($_POST['s3_exams_year']) == '2004')?'selected':''); ?>>2004</option>
                                                                <option value="2003" <?= ((isset($_POST['s3_exams_year']) == '2003')?'selected':''); ?>>2003</option>
                                                                <option value="2002" <?= ((isset($_POST['s3_exams_year']) == '2002')?'selected':''); ?>>2002</option>
                                                                <option value="2001" <?= ((isset($_POST['s3_exams_year']) == '2001')?'selected':''); ?>>2001</option>
                                                                <option value="2000" <?= ((isset($_POST['s3_exams_year']) == '2000')?'selected':''); ?>>2000</option>
                                                            </select>
                                                            <small class="text-danger">NB: Choose the appropriate examination year please.</small>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="table-responsive">
                                                                <table class="table table-sm">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Suject</th>
                                                                            <th>Result</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>Social Studies</td>
                                                                            <input type="hidden" name="s3_corecourse11" value="Social Studies">
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_coreresult11" >
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                         </tr>
                                                                        <tr>
                                                                            <td>English Language</td>
                                                                            <input type="hidden" name="s3_corecourse12" value="English Language">
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_coreresult12" >
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Mathematics(Core)</td>
                                                                            <input type="hidden" name="s3_corecourse13" value="Mathematics(Core)">
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_coreresult13" >
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Integrated Science</td>
                                                                            <input type="hidden" name="s3_corecourse14" value="Integrated Science">
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_coreresult14" >
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="2"><b>Choose Electives and results</b></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2" name="s3_electivecourse11">
                                                                                    <option>Choose Subject</option>
                                                                                    <option value="General Agriculture">General Agriculture</option>
                                                                                    <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                    <option value="Physics">Physics</option>
                                                                                    <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                    <option value="Geography">Geography</option>
                                                                                    <option value="Music">Music</option>
                                                                                    <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                    <option value="Business Management">Business Management</option>
                                                                                    <option value="French">French</option>
                                                                                    <option value="Management-In-Living">Management-In-Living</option>
                                                                                    <option value="Sculpture">Sculpture</option>
                                                                                    <option value="Literature-in English">Literature-in English</option>
                                                                                    <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                    <option value="Arabic">Arabic</option>
                                                                                    <option value="Government">Government</option>
                                                                                    <option value="History">History </option>
                                                                                    <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                    <option value="Ewe">Ewe</option>
                                                                                    <option value="Ga">Ga</option>
                                                                                    <option value="Gonja">Gonja</option>
                                                                                    <option value="Kasem">Kasem</option>
                                                                                    <option value="Nzema">Nzema</option>
                                                                                    <option value="Twi (Asante)">Twi (Asante)</option>
                                                                                </select>
                                                                            </td>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_electiveresult11" >
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr><tr>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2" name="s3_electivecourse12">
                                                                                    <option>Choose Subject</option>
                                                                                    <option value="General Agriculture">General Agriculture</option>
                                                                                    <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                    <option value="Physics">Physics</option>
                                                                                    <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                    <option value="Geography">Geography</option>
                                                                                    <option value="Music">Music</option>
                                                                                    <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                    <option value="Business Management">Business Management</option>
                                                                                    <option value="French">French</option>
                                                                                    <option value="Management-In-Living">Management-In-Living</option>
                                                                                    <option value="Sculpture">Sculpture</option>
                                                                                    <option value="Literature-in English">Literature-in English</option>
                                                                                    <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                    <option value="Arabic">Arabic</option>
                                                                                    <option value="Government">Government</option>
                                                                                    <option value="History">History </option>
                                                                                    <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                    <option value="Ewe">Ewe</option>
                                                                                    <option value="Ga">Ga</option>
                                                                                    <option value="Gonja">Gonja</option>
                                                                                    <option value="Kasem">Kasem</option>
                                                                                    <option value="Nzema">Nzema</option>
                                                                                    <option value="Twi (Asante)">Twi (Asante)</option>
                                                                                </select>
                                                                            </td>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_electiveresult12">
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr><tr>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2" name="s3_electivecourse13">
                                                                                    <option>Choose Subject</option>
                                                                                    <option value="General Agriculture">General Agriculture</option>
                                                                                    <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                    <option value="Physics">Physics</option>
                                                                                    <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                    <option value="Geography">Geography</option>
                                                                                    <option value="Music">Music</option>
                                                                                    <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                    <option value="Business Management">Business Management</option>
                                                                                    <option value="French">French</option>
                                                                                    <option value="Management-In-Living">Management-In-Living</option>
                                                                                    <option value="Sculpture">Sculpture</option>
                                                                                    <option value="Literature-in English">Literature-in English</option>
                                                                                    <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                    <option value="Arabic">Arabic</option>
                                                                                    <option value="Government">Government</option>
                                                                                    <option value="History">History </option>
                                                                                    <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                    <option value="Ewe">Ewe</option>
                                                                                    <option value="Ga">Ga</option>
                                                                                    <option value="Gonja">Gonja</option>
                                                                                    <option value="Kasem">Kasem</option>
                                                                                    <option value="Nzema">Nzema</option>
                                                                                    <option value="Twi (Asante)">Twi (Asante)</option>
                                                                                </select>
                                                                            </td>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_electiveresult13">
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2" name="s3_electivecourse14">
                                                                                    <option>Choose Subject</option>
                                                                                    <option value="General Agriculture">General Agriculture</option>
                                                                                    <option value="Animal Husbandry">Animal Husbandry </option>
                                                                                    <option value="Physics">Physics</option>
                                                                                    <option value="Mathematics (Elective)">Mathematics (Elective)</option>
                                                                                    <option value="Geography">Geography</option>
                                                                                    <option value="Music">Music</option>
                                                                                    <option value="ICT (Elective)">ICT (Elective)</option>
                                                                                    <option value="Business Management">Business Management</option>
                                                                                    <option value="French">French</option>
                                                                                    <option value="Management-In-Living">Management-In-Living</option>
                                                                                    <option value="Sculpture">Sculpture</option>
                                                                                    <option value="Literature-in English">Literature-in English</option>
                                                                                    <option value="Christian Religious Studies">Christian Religious Studies</option>
                                                                                    <option value="Arabic">Arabic</option>
                                                                                    <option value="Government">Government</option>
                                                                                    <option value="History">History </option>
                                                                                    <option value="Islamic Religious Studies">Islamic Religious Studies</option>
                                                                                    <option value="Ewe">Ewe</option>
                                                                                    <option value="Ga">Ga</option>
                                                                                    <option value="Gonja">Gonja</option>
                                                                                    <option value="Kasem">Kasem</option>
                                                                                    <option value="Nzema">Nzema</option>
                                                                                    <option value="Twi (Asante)">Twi (Asante)</option>
                                                                                </select>
                                                                            </td>
                                                                            <td>
                                                                                <select class="form-control form-control-sm select2 select2-hidden-accessible"  name="s3_electiveresult14">
                                                                                    <option></option>
                                                                                    <option value="A1">A1</option>
                                                                                    <option value="B2">B2</option>
                                                                                    <option value="B3">B3</option>
                                                                                    <option value="C4">C4</option>
                                                                                    <option value="C5">C5</option>
                                                                                    <option value="C6">C6</option>
                                                                                    <option value="D7">D7</option>
                                                                                    <option value="E8">E8</option>
                                                                                    <option value="F9">F9</option>
                                                                                    <option value="A">A</option>
                                                                                    <option value="B">B</option>
                                                                                    <option value="C">C</option>
                                                                                    <option value="D">D</option>
                                                                                    <option value="E">E</option>
                                                                                    <option value="F">F</option>
                                                                                    <option>Awaiting Results</option>
                                                                                </select>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>







                                                <div class="col-md-12">
                                                    <button type="submit" name="submit" id="submit" class="btn btn-success">Submit Examination History</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

    </div>


    <?php 
        include ("footer.php");
    ?>