<?php 


    require_once ("../connection/conn.php");
    require "../PHPMailer/PHPMailerAutoload.php";


    if (!is_logged_in()) {
        login_error_redirect();
    }

    $output = '';
    $query = "
        SELECT * FROM admissions
        WHERE  trash = :trash
        ORDER BY id DESC
    ";
    $statement = $conn->prepare($query);
    $statement->execute([':trash' => 0]);
    $count_row = $statement->rowCount();
    $result = $statement->fetchAll();

    if ($count_row > 0) {
        $i = 1;
        foreach ($result as $row) {
            $status = '';
            if ($row["status"] == 0) {
                $status = '#dac2c4';
            }

            $st = '';
            if ($row['verified'] == 0) {
                $st = '<span class="badge bg-secondary shadow-lg">not-verified</span>';
            } else if ($row['verified'] == 1) {
                $st = '<span class="badge bg-warning shadow-lg">verified</span>';
            }

            if ($row['done'] == 1) {
                $st = '<span class="badge bg-info shadow-lg">completed</span>';
            }

            if ($row['granted'] == 1) {
                $st = '<span class="badge bg-success shadow-lg">granted</span>';
            } else if ($row['granted'] == 2) {
                $st = '<span class="badge bg-danger shadow-lg">fake</span>';
            }
            $output .= '
                <tr style="background-color: '.$status.'">
                    <td>'.$i.'</td>
                    <td>'.ucwords($row["student_id"]).'</td>
                    <td>'.ucwords($row["first_name"].' '. $row["middle_name"].' '.$row["last_name"]).'</td>
                    <td>'.$row["email"].'</td>
                    <td>'.$row["admission_type"].'</td>
                    <td>'.pretty_date($row["reg_date"]).'</td>
                    <td>'.$st.'</td>
                    <td>
                        <a href="index.php?view=1&id='.$row["id"].'" class="btn btn-sm btn-outline-secondary"><span data-feather="eye"></span></a>&nbsp|&nbsp;
                        <!-- <a href="index.php?pdf=1&id='.$row["id"].'" class="btn btn-sm btn-outline-primary" target="_blank"><span data-feather="file-text"></span></a>&nbsp|&nbsp; -->
                        <a href="index.php?delete=1&id='.$row["id"].'" class="btn btn-sm btn-outline-danger"><span data-feather="trash-2"></span></a>
                    </td>
                </tr>
            ';
            $i++;
        }
    } else {
        $output = '
            <tr>
                <td colspan="7" class="bg-secondary p-3 h3">No data found.</td>
            </tr>
        ';
    }

    // VIEW ADMISSION
    if (isset($_GET['view']) && !empty($_GET['id'])) {
        $id = (int)$_GET['id'];
        $view_query = "
            SELECT * FROM admissions
            INNER JOIN admission_details
            ON admission_details.admission_id = admissions.id
            LEFT JOIN examination_seating_one
            ON examination_seating_one.admission_id = admissions.id
            LEFT JOIN examination_seating_two
            ON examination_seating_two.admission_id = admissions.id
            LEFT JOIN examination_seating_three
            ON examination_seating_three.admission_id = admissions.id
            WHERE admissions.trash = :trash
            AND admissions.id = :id
            LIMIT 1
        ";
        $statement = $conn->prepare($view_query);
        $statement->execute([':trash' => 0, ':id' => $id]);
        $view_count = $statement->rowCount();
        $view_result = $statement->fetchAll();

        if ($view_count > 0) {
            $query2 = "
                UPDATE admissions
                SET status = :status
                WHERE id = :id
            ";
            $statement = $conn->prepare($query2);
            $statement->execute([':status' => 1, ':id' => $id]);
            foreach ($view_result as $view_row) {
                // code...
            }
        } else {
            $_SESSION['flash_error'] = "Admission INVALID!";
            header("Location: index.php");
        }
    }

    // VERIFY ADMISSION
    if (isset($_GET['verify']) && !empty($_GET['id'])) {
        $id = (int)$_GET['id'];
        $verify_query = "
            SELECT * FROM admissions
            WHERE trash = :trash
            AND id = :id
            LIMIT 1
        ";
        $statement = $conn->prepare($verify_query);
        $statement->execute([':trash' => 0, ':id' => $id]);
        $verify_result = $statement->fetchAll();
        $verify_count = $statement->rowCount();

        if ($verify_count > 0) {
            $query = "
                UPDATE admissions
                SET granted = :granted
                WHERE id = :id
            ";
            $statement = $conn->prepare($query);
            $result = $statement->execute([':granted' => 1, ':id' => $id]);
            if (isset($result)) {

                foreach ($verify_result as $verify_row) {
                    $to   = $verify_row['email'];
                    $from = 'info@thylies.com';
                    $from_name = 'U . D . S, GH';
                    $subject = 'University of Development Studies.';
                    $body = '<p>Dear '.ucwords($verify_row['first_name'] . ' ' . $verify_row['middle_name'] . ' ' . $verify_row['last_name']).'.</p>
                            <p>You have been successfully granted admission to University of Development Studies.</p>
                            <br>
                            <p>Best Regards, <br> NCU</p>';

                    $mail = new PHPMailer();
                    $mail->IsSMTP();
                    $mail->SMTPAuth = true; 
                                                 
                    $mail->SMTPSecure = 'ssl'; 
                    $mail->Host = 'smtp.thylies.com';
                    $mail->Port = 465;  
                    $mail->Username = 'info@thylies.com';
                    $mail->Password = 'Un0549f7d';
                                                   
                    $mail->IsHTML(true);
                    $mail->WordWrap = 50;
                    $mail->From = "info@thylies.com";
                    $mail->FromName = $from_name;
                    $mail->Sender = $from;
                    $mail->AddReplyTo($from, $from_name);
                    $mail->Subject = $subject;
                    $mail->Body = $body;
                    $mail->AddAddress($to);
                    $resultMail = $mail->Send();

                    if (!$resultMail) {
                        echo "<script>alert('Please try Later, Error Occured while Processing...');</script>";
                    } else {
                        $_SESSION['flash_success'] = "Admission successfully GRANTED!";
                        header("Location: index.php");
                    }
                }
            }
        } else {
            $_SESSION['flash_error'] = "Admission UNKNOWN!";
            header("Location: index.php");
        }
    }

    // REJECT ADMISSION
    if (isset($_GET['deny']) && !empty($_GET['id'])) {
        $id = (int)$_GET['id'];
        $deny_query = "
            SELECT * FROM admissions
            WHERE trash = :trash
            AND id = :id
            LIMIT 1
        ";
        $statement = $conn->prepare($deny_query);
        $statement->execute([':trash' => 0, ':id' => $id]);
        $deny_count = $statement->rowCount();

        if ($deny_count > 0) {
            $query = "
                UPDATE admissions
                SET granted = :granted
                WHERE id = :id
            ";
            $statement = $conn->prepare($query);
            $result = $statement->execute([':granted' => 2, ':id' => $id]);
            if (isset($result)) {
               $_SESSION['flash_success'] = "Admission successfully REJECTED!";
                header("Location: index.php");
            }
        } else {
            $_SESSION['flash_error'] = "Admission UNKNOWN!";
            header("Location: index.php");
        }
    }

    // DELETE ADMISSION
    if (isset($_GET['delete']) && !empty($_GET['id'])) {
        $id = (int)$_GET['id'];
        $delete_query = "
            SELECT * FROM admissions
            WHERE trash = :trash
            AND id = :id
            LIMIT 1
        ";
        $statement = $conn->prepare($delete_query);
        $statement->execute([':trash' => 0, ':id' => $id]);
        $delete_count = $statement->rowCount();

        if ($delete_count > 0) {
            $query = "
                UPDATE admissions
                SET trash = :trash
                WHERE id = :id
            ";
            $statement = $conn->prepare($query);
            $result = $statement->execute([':trash' => 1, ':id' => $id]);
            if (isset($result)) {
               $_SESSION['flash_success'] = "Admission successfully DELETED!";
                header("Location: index.php");
            }
        } else {
            $_SESSION['flash_error'] = "Admission UNKNOWN!";
            header("Location: index.php");
        }
    }



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Admin . NCU</title>


    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="media/logo-1.png" type="image/x-icon">

    <meta name="theme-color" content="#7952b3">


    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
</head>
<body>
        
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Company name</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-nav">
            <div class="nav-item text-nowrap">
                <a class="nav-link px-3" href="logout.php">Sign out</a>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">
                                <span data-feather="home"></span>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="none-v.php">
                                <span data-feather="file"></span>
                                None Verified
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="verified.php">
                                <span data-feather="shopping-cart"></span>
                                Verified
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-info" href="completed.php">
                                <span data-feather="users"></span>
                                Completed
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-success" href="granted.php">
                                <span data-feather="bar-chart-2"></span>
                                Granted
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="fake.php">
                                <span data-feather="layers"></span>
                                Fake
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Saved reports</span>
                        <a class="link-secondary" href="#" aria-label="Add a new report">
                            <span data-feather="plus-circle"></span>
                        </a>
                    </h6>
                    <ul class="nav flex-column mb-2">
                        <li class="nav-item">
                            <a class="nav-link" href="details.php">
                                <span data-feather="file-text"></span>
                                Hi <?= $fname; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <span data-feather="file-text"></span>
                                Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="change-pass.php">
                                <span data-feather="file-text"></span>
                                Change password
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <span data-feather="file-text"></span>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                    </div>
                </div>

                <?php if (isset($_GET['view']) && !empty($_GET['id'])): ?>
                
                <div class="card mb-3">
                    <div class="card-body">
                        <fieldset disabled>
                            <legend>Bio Data</legend>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">First Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['first_name']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Middle Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['middle_name']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Last Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['last_name']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Sex</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['sex']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Date of Birth</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $view_row['dob']; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Nationality</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['nationality']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Religion</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['religion']); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label>Passport Picture</label>
                                <?php if ($view_row['passport_pic'] != ''): ?>
                                    <img src="../media/students/<?= $view_row['passport_pic']; ?>" class="img-thumbnail" width="100" height="100">
                                <?php else: ?>
                                    <em>No Passport Picture!</em>
                                <?php endif; ?>
                            </div>

                            <hr>

                            <legend>Examination History</legend>
                            <h4>Seating One</h4>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Index Number</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?= $view_row['index_number']; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Examination Year</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?= $view_row['exams_year']; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>SUJECT</th>
                                                <th>RESULT</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['corecourse11']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['coreresult11']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['corecourse12']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['coreresult12']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['corecourse13']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['coreresult13']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['corecourse14']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['coreresult14']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['electivecourse11']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['electiveresult11']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['electivecourse12']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['electiveresult12']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['electivecourse13']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['electiveresult13']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['electivecourse14']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['electiveresult14']; ?>"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <?php if ($view_row['s2_index_number'] != '' && $view_row['s2_exams_year'] != ''): ?>
                            <h4>Seating Two</h4>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Index Number</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?= $view_row['s2_index_number']; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Examination Year</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?= $view_row['s2_exams_year']; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>SUJECT</th>
                                                <th>RESULT</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_corecourse11']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_coreresult11']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_corecourse12']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_coreresult12']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_corecourse13']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_coreresult13']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_corecourse14']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_coreresult14']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_electivecourse11']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_electiveresult11']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_electivecourse12']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_electiveresult12']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_electivecourse13']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_electiveresult13']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s2_electivecourse14']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s2_electiveresult14']; ?>"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php else: ?>
                                <div class="row mb-3">
                                <p class="lead">No Data for Seating Two</p>
                            </div>
                            <?php endif; ?>

                            <?php if ($view_row['s3_index_number'] != '' && $view_row['s3_exams_year'] != ''): ?>
                            <h4>Seating Three</h4>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Index Number</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?= $view_row['s3_index_number']; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Examination Year</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?= $view_row['s3_exams_year']; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>SUJECT</th>
                                                <th>RESULT</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_corecourse11']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_coreresult11']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_corecourse12']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_coreresult12']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_corecourse13']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_coreresult13']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_corecourse14']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_coreresult14']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_electivecourse11']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_electiveresult11']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_electivecourse12']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_electiveresult12']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_electivecourse13']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_electiveresult13']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <td><input class="form-control" value="<?= $view_row['s3_electivecourse14']; ?>"></td>
                                                <td><input class="form-control" value="<?= $view_row['s3_electiveresult14']; ?>"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php else: ?>
                                <div class="row mb-3">
                                <p class="lead">No Data for Seating Three</p>
                            </div>
                            <?php endif; ?>

                            <hr>

                            <legend>Personal Contact Information</legend>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Address</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" rows="2"><?= nl2br($view_row['postal_address']); ?></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">City</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['city']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Postal Region/State</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['region_state']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Phone</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $view_row['phone']; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Email</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $view_row['email']; ?>">
                                </div>
                            </div>

                            <hr>

                            <legend>Personal Contact Information</legend>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">First Choice</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['first_cp']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Second Choice</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['second_cp']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Third Choice</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['third_cp']); ?>">
                                </div>
                            </div>

                            <hr>

                            <legend>Document Details</legend>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Examination Type</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['exams_type']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Name of School</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['school']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Document Type</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= ucwords($view_row['cert_info']); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label>Document File</label>
                                <?php if ($view_row['upload_cert'] == ''): ?>
                                    <em>No Document file uploaded!</em>
                                <?php else: ?>
                                    <em>File uploaded successfully,</em> <a href="../media/students_docs/<?= $view_row['upload_cert']; ?>" target="_blank">preview and download here...</a>
                                <?php endif; ?>
                            </div>
                        </fieldset>

                        <hr>
                        <div class="mb-3">
                            <a href="index.php?verify=1&id=<?= $view_row['id']; ?>" class="btn btn-secondary">Verify Admission</a>
                            <a href="index.php?deny=1&id=<?= $view_row['id']; ?>" class="btn btn-primary">Deny Admission</a>
                            <a href="https://ghana.waecdirect.org/" class="btn btn-warning">Check to approve Result</a>
                            <a href="index.php" class="btn btn-dark" style="float: right;">Go back</a>
                        </div>
                    </div>
                </div>

                <?php else: ?>
                <section>
                    <div class="row">
                        <div class="col-md">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <h3 class="bd-title mt-0">None Verified Account</h3>
                                    <p class="mt-2 h2 text-info" style="float: right;"># <?= count_none_verified_account(); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <h3 class="bd-title mt-0">Verified Account</h3>
                                    <p class="mt-2 h2 text-info" style="float: right;"># <?= count_verified_account(); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <h3 class="bd-title mt-0">Completed Admissions</h3>
                                    <p class="mt-2 h2 text-info" style="float: right;"># <?= count_completed_admissions(); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <h3 class="bd-title mt-0">Admission Granted</h3>
                                    <p class="mt-2 h2 text-info" style="float: right;"># <?= count_granted_admissions(); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="col-auto">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <p class="lead text-danger">Fake documets: <span class="text-dark"><b><?= count_fake_documents(); ?></b></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <br><br>
                <h2 class="mt-5">Admissions list</h2>
                <div class="table-responsive">
                    <table class="table table-striped table-sm">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Student ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Admission Type</th>
                                <th scope="col">Registered Date</th>
                                <th scope="col">Status</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <?= $output; ?>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <?php endif; ?>

            </main>
        </div>
    </div>


    <script src="bootstrap.bundle.min.js"></script>
    <script src="feather.min.js"></script>
    <script src="dashboard.js"></script>
</body>
</html>
