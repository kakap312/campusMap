<?php 


    require_once ("../connection/conn.php");

	unset($_SESSION['adminId']);
	
	header('Location: login.php');


?>