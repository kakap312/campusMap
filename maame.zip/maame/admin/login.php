<?php 


    require_once ("../connection/conn.php");

    if (is_logged_in()) {
        header('Location: index.php');
    }

    $email = ((isset($_POST['email']))?sanitize($_POST['email']):'');
    $email = trim($email);
    $password = ((isset($_POST['password']))?sanitize($_POST['password']):'');
    $password = trim($password);

    $msg = '';
    if ($_POST) {
        if (empty($_POST['email']) || empty($_POST['password'])) {
             $msg = 'You must provide all empty fields.';
        } else {
        
            $statement = $conn->prepare("SELECT * FROM admin WHERE email = '$email'");
            $statement->execute();
            $result = $statement->fetchAll();
            $userCount = $statement->rowCount();
            if ($userCount > 0) {
                foreach ($result as $row) {
                    if (!password_verify($password, $row['password'])) {
                        $msg = 'The password does not match our records. Please try again.';
                    }

                    if (!empty($msg)) {
                        $msg;
                    } else {
                        $user_id = $row['admin_id'];
                        login($user_id);
                    }
                }
            } else {
                $msg = 'That email doesn\'t exist in our database';
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Admin . NCU</title>


    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

        <!-- Favicons -->
    <!-- <link rel="apple-touch-icon" href="/docs/5.0/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
    <link rel="manifest" href="/docs/5.0/assets/img/favicons/manifest.json">
    <link rel="mask-icon" href="/docs/5.0/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon.ico"> -->
    <meta name="theme-color" content="#7952b3">


    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
</head>
<body>

    <div class="row justify-content-center mt-5">
        <div class="col-md-4 shadow-lg" style="border-top: 4px solid tomato; padding: 20px; border-radius: 6px; background: #e4e4e4;">
            <h3 class="pt-3" style="border-bottom: 1px dotted black;">Admin . Log into dashboard</h3>
            <div class="form mt-5">
                <ul>
                    <li class="text-danger"><?= $msg; ?></li>
                </ul>
                <form method="POST" action="login.php">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="email" name="email" class="form-control form-control-lg" value="<?= $email; ?>">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="Password" name="password" class="form-control form-control-lg" value="<?= $password; ?>">
                    </div>
                    <div class="form-group mt-5">
                        <input type="submit" class="btn btn-lg btn-dark" value="Log In.">
                        <a href="../index.php" style="float: right;">visit site</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="bootstrap.bundle.min.js"></script>
    <script src="feather.min.js"></script>
    <script src="dashboard.js"></script>
</body>
</html>