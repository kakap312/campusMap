<?php 


    require_once ("../connection/conn.php");

    if (!is_logged_in()) {
        login_error_redirect();
    }

    $fname = ((isset($_POST['fname']))?sanitize($_POST['fname']) : $fname);
    $lname = ((isset($_POST['lname']))?sanitize($_POST['lname']) : $lName);
    $email = ((isset($_POST['email']))?sanitize($_POST['email']) : $row['email']);
    $user_id = $row['admin_id'];
    if (isset($_POST['submit'])) {
        $query = "
            UPDATE admin
            SET fname = :fname, lname = :lname, email = :email
            WHERE admin_id  = :admin_id
        ";
        $statement = $conn->prepare($query);
        $result = $statement->execute([
            ':fname'        => $fname,
            ':lname'        => $lname,
            ':email'        => $email,
            ':admin_id'     => (int)$user_id
        ]);

        if (isset($result)) {
            $_SESSION['flash_success'] = "Admin details successfully UPDATED!";
            header("Location: details.php");
        }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Admin . NCU</title>


    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

        <!-- Favicons -->
    <!-- <link rel="apple-touch-icon" href="/docs/5.0/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
    <link rel="manifest" href="/docs/5.0/assets/img/favicons/manifest.json">
    <link rel="mask-icon" href="/docs/5.0/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon.ico"> -->
    <meta name="theme-color" content="#7952b3">


    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
</head>
<body>
        
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Company name</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-nav">
            <div class="nav-item text-nowrap">
                <a class="nav-link px-3" href="logout.php">Sign out</a>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">
                                <span data-feather="home"></span>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="none-v.php">
                                <span data-feather="file"></span>
                                None Verified
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="verified.php">
                                <span data-feather="shopping-cart"></span>
                                Verified
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-info" href="completed.php">
                                <span data-feather="users"></span>
                                Completed
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-success" href="granted.php">
                                <span data-feather="bar-chart-2"></span>
                                Granted
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="fake.php">
                                <span data-feather="layers"></span>
                                Fake
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Saved reports</span>
                        <a class="link-secondary" href="#" aria-label="Add a new report">
                            <span data-feather="plus-circle"></span>
                        </a>
                    </h6>
                    <ul class="nav flex-column mb-2">
                        <li class="nav-item">
                            <a class="nav-link" href="details.php">
                                <span data-feather="file-text"></span>
                                Hi <?= $fname; ?>!
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <span data-feather="file-text"></span>
                                Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="change-pass.php">
                                <span data-feather="file-text"></span>
                                Change password
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <span data-feather="file-text"></span>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Admin Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                    </div>
                </div>

                <section>
                    <div class="card shadow-lg">
                        <div class="card-body">
                            <form method="POST" action="settings.php">
                                <div class="form-group mb-3">
                                    <label class="lead">First Name</label>
                                    <input type="text" value="<?= $fname; ?>" id="fname" name="fname" class="form-control form-control-lg">
                                </div>
                                <div class="form-group mb-3">
                                    <label class="lead">Last Name</label>
                                    <input type="text" name="lname" id="lname" value="<?= $lname; ?>" class="form-control form-control-lg">
                                </div>
                                <div class="form-group mb-3">
                                    <label class="lead">E-Mail</label>
                                    <input type="email" name="email" id="email" value="<?= $email; ?>" class="form-control form-control-lg">
                                </div>
                                <div class="form-group mb-3">
                                    <button class="btn btn-lg btn-dark" name="submit" id="submit" name="submit" type="submit">Update Details</button>&nbsp;
                                    <a href="change-pass.php">change password</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>

            </main>
        </div>
    </div>


    <script src="bootstrap.bundle.min.js"></script>
    <script src="feather.min.js"></script>
    <script src="dashboard.js"></script>
</body>
</html>
