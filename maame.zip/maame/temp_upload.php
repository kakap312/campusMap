<?php 

	// Upload Post Image And Save To Draft 

	// Include External Files;
	require_once ('connection/conn.php');

	if ($_FILES["ppic"]["name"]  != '') {

		$test = explode(".", $_FILES["ppic"]["name"]);
		$extention = end($test);
		$name = rand(100, 999) . '.' . $extention;
		$location = BASEURL.'media/temporary_files/'.$name;
		$move = move_uploaded_file($_FILES["ppic"]["tmp_name"], $location);
		if ($move) {
			echo '
				<div id="tu_file">
					<span class="thumb-image-delete" id="image_to_0">
						<span class="pointer thumb-image-delete-btn removeFile" id="'.$location.'">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path fill="currentColor" d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"></path></svg>
						</span>
						<img src="media/temporary_files/'.$name.'" alt="" class="thumb-image">
						<input type="hidden" name="uploadedFile" id="uploadedFile" value="'.$location.'">
					</span>
				</div>
				';
		} else {
			echo "There was an error whilst uploading you picture";
		}
	}

?>

<style>
.thumb-image-delete {
    position: relative;
    display: inline-block;
}

.thumb-image-delete-btn {
    position: absolute;
    right: 5px;
    top: 5px;
    color: white;
    background-color: rgba(0, 0, 0, 0.3);
    border-radius: 50%;
    text-align: center;
    line-height: 1;
    padding: 3px;
}

.pointer {
    cursor: pointer;
}

#image-holder .thumb-image:last-child {
    margin-right: 0;
}

#image-holder .thumb-image {
    width: 100px;
    height: 100px;
    margin: 8px 5px 0 0;
    display: inline-block;
    object-fit: cover;
    user-select: none;
    pointer-events: none;
    border-radius: 4px;
}
</style>
