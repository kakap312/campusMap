<?php 

	require_once ("connection/conn.php");
	
	include ("head.php");

	$email = '';
	if (isset($_GET['id']) && !empty($_GET['id'])) {
		$id = (int)$_GET['id'];

		$query = "SELECT email FROM admissions WHERE id = :id LIMIT 1";
		$statement = $conn->prepare($query);
		$statement->execute([':id' => $id]);

		$fetch_row = $statement->fetchAll();
		$count_row = $statement->rowCount();

		if ($count_row > 0) {
			foreach ($fetch_row as $row) {
				$email = $row['email'];
			}
		} else {
			header("Location: index.php");
		}
	} else {
		header("Location: index.php");
	}
?>


	<section class="bg-green py-15 py-xl-20 mx-xl-3 overflow-hidden">
    		<div class="container level-3">
		      	<div class="row">
		        	<div class="col-lg-8 col-xl-6 inverted text-center text-lg-start">
			          	<h2 class="h1 mb-0">Hi, <b><?= $email; ?></b>.</h2>
			          	<p class="lead text-secondary my-4">Please you have receive an email confirmation message and login details to the student portal, check your inbox, or your spam box to verify your account and continue your admission 
			          		registration process.
			          		<br><br>
			          		Best Regards, NCU.
			          	</p>
			          	<a href="index.php" class="btn btn-outline-white btn-lg btn-with-icon rounded-pill">Go back home <i
			              class="bi bi-arrow-right"></i></a>
			        </div>
		      	</div>
		    </div>
		<figure class="background background-gradient-horizontal background-parallax"
		      style="background-image: url('media/pic3.jpg')" data-bottom-top="transform: translateY(0%);"
		      data-top-bottom="transform: translateY(20%);"></figure>
  	</section>

<?php 
    include ("footer.php");
?>