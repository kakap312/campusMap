<?php   

    require_once ("connection/conn.php");

    if (!isset($_SESSION['id'])) {
        header('Location: sign-in.php');
    }

    if ($select_row['done'] == 1) {
        header('Location: dashboard.php');
    }

    include ("head.php");

    if (isset($_POST['submit'])) {
         $update_query = "
            UPDATE admissions
            SET done = :done
            WHERE id = :id
        ";
        $statement = $conn->prepare($update_query);
        $result = $statement->execute([
            ':done'     => (int)$_POST['done'],
            ':id'     => (int)$_SESSION['id']
        ]);

        if (isset($result)) {
            header('Location: dashboard.php');
        }
    }
?>

<body class="bg-light">

    <nav id="mainNav" class="navbar navbar-expand-lg navbar-sticky navbar-light bg-light border-bottom">
        <div class="container">
            <a href="account-settings.php" class="navbar-brand"><img src="media/logo-1.png" alt="Logo"></a>
  
            <ul class="navbar-nav navbar-nav-secondary order-lg-3">
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>

                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#userNav"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-hover d-none d-lg-block">
                    <a class="nav-link nav-icon" role="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                        <i class="bi bi-person"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                        <li><a class="dropdown-item" href="account-settings.php">Bio Data</a></li>
                        <li><a class="dropdown-item" href="contact-info.php">Contact Information</a></li>
                        <li><a class="dropdown-item" href="choice-prog.php">Choice of Programmes</a></li>
                        <li><a class="dropdown-item" href="examination-history.php">Examination History</a></li>
                        <li><a class="dropdown-item" href="document-upload.php">Document Upload</a></li>
                        <li><a class="dropdown-item active" href="done.php">Done</a></li>
                        <li><a class="dropdown-item text-red" href="sign-out.php">Log Out</a></li>
                    </ul>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link nav-icon" href="" role="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                    aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </a>
                </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbar" data-bs-parent="#mainNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown dropdown-hover">
                        <a class="nav-link" href="dashboard.php" role="button">
                            Home
                        </a>
                    </li><!-- 
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            GRADUATE PROGRAMS
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" role="button">
                            Admission List
                        </a>
                    </li> -->
                      
                    <li class="nav-item d-lg-none">
                        <a href="sign-in.php" class="nav-link text-primary">Student Portal</a>
                    </li>
                </ul>
            </div>
        
        </div>
  </nav>

    <div class="offcanvas-wrap">
        <section class="split">
            <div class="container">
                <div class="row justify-content-between">

                    <aside class="col-lg-3 split-sidebar">
                        <nav class="sticky-top d-none d-lg-block">
                            <ul class="nav nav-minimal flex-column" id="toc-nav">
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="dashboard.php">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="account-settings.php">Bio Data</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="contact-info.php">Contact Information</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="choice-prog.php">Choice of Programmes</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="examination-history.php">Examination History</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg" href="document-upload.php">Document Upload</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg active" href="done.php">Done</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link fs-lg text-red" href="sign-out.php">Sign Out</a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <div class="col-lg-9 split-content">
                        <div class="row">
                            <div class="col-lg-10">
                                <h1>Done</h1>
                                <div class="alert alert-success mb-0" role="alert">
                                    Please we advice you to go over the forms again and check for any errors or mistakes before submitting it. <br> And also your document details is very essential to us, make sure every single detail you provided is right. Remember after you click on the submit button below there is no way to change or modify any deatils.
                                </div>
                            </div>
                        </div>

                        <section>
                            <div class="row">
                                <div class="col-lg-10">
                                    <div class="card bg-opaque-white">
                                        <div class="card-body bg-white">
                                            <form class="row g-2 g-lg-3" method="POST" action="done.php">
                                                <div class="col-md-12">
                                                    <input type="hidden" name="done" id="done" value="1">
                                                    <button type="submit" name="submit" id="submit" class="btn btn-success" onclick="alert('There will be no going back after this command');">Submit My Application</button>&nbsp;&nbsp;
                                                    <a href="account-settings.php"><<< Check over again</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

    </div>


    <?php 
        include ("footer.php");
    ?>